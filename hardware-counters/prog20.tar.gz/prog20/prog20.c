/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.2.0
 * Git version: bf42ffd
 * Options:   (none)
 * Seed:      3100228177
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   const volatile uint8_t  f0;
   int8_t  f1;
   int8_t  f2;
   volatile int8_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint64_t g_9 = 18446744073709551614UL;/* VOLATILE GLOBAL g_9 */
static int32_t g_14 = (-10L);
static int32_t *g_13 = &g_14;
static int32_t g_21 = 0L;
static uint32_t g_23 = 0xCF0ADC10L;
static const int32_t g_28 = 9L;
static uint32_t g_62[7][9] = {{0x51B70F82L,0xB76FC491L,0x6F5D9AEBL,0x6F5D9AEBL,0xB76FC491L,0x51B70F82L,4294967293UL,0x41B6ADD7L,0x6F5D9AEBL},{4294967295UL,6UL,0x5F713EC2L,0xB78960BDL,0x15D2BB39L,4294967295UL,4294967295UL,0x15D2BB39L,0xB78960BDL},{0xF595C982L,0xB76FC491L,0xF595C982L,0x51B70F82L,0x9B7B3FA8L,0xF595C982L,4294967293UL,0xFCCFF5F9L,0x51B70F82L},{1UL,0x15D2BB39L,0x5F713EC2L,1UL,4294967295UL,1UL,0x5F713EC2L,0x15D2BB39L,1UL},{4294967286UL,0x9B7B3FA8L,0x6F5D9AEBL,0x51B70F82L,4294967295UL,4294967286UL,0x51B70F82L,0x41B6ADD7L,0x51B70F82L},{0x5F713EC2L,4294967295UL,0x81DC493AL,0x81DC493AL,4294967295UL,4294967291UL,1UL,4294967295UL,0x81DC493AL},{4UL,0x51B70F82L,4294967295UL,1UL,0xF595C982L,4UL,4UL,0xF595C982L,1UL}};
static uint32_t g_66[10][7] = {{4294967289UL,0x18A90745L,4UL,0x103D53AFL,0UL,0UL,0x103D53AFL},{0x6B3E6299L,4294967289UL,0x6B3E6299L,1UL,8UL,0UL,0UL},{4UL,0x18A90745L,4294967289UL,0x4183AA7AL,4294967289UL,0x18A90745L,4UL},{0xEB1CB69AL,4294967293UL,0UL,8UL,4294967287UL,0UL,4294967287UL},{0x18A90745L,6UL,6UL,0x18A90745L,4294967293UL,0UL,0x4183AA7AL},{4UL,4294967295UL,0UL,0x6B3E6299L,0x6B3E6299L,0UL,4294967295UL},{4294967293UL,4UL,4294967289UL,4294967290UL,6UL,0x4183AA7AL,0x4183AA7AL},{0UL,4UL,0x6B3E6299L,4UL,0UL,4294967293UL,4294967287UL},{0x2D48012CL,0UL,4UL,4294967290UL,0x103D53AFL,4294967290UL,4UL},{4294967287UL,4294967287UL,0xEB1CB69AL,0x6B3E6299L,4294967295UL,1UL,0UL}};
static int64_t g_67 = 0x47F2DBD2431EA725LL;
static uint32_t g_69 = 0xF00C75B8L;
static union U0 g_90 = {0UL};/* VOLATILE GLOBAL g_90 */
static union U0 g_93[9] = {{0xBBL},{0xBBL},{0xBBL},{0xBBL},{0xBBL},{0xBBL},{0xBBL},{0xBBL},{0xBBL}};
static uint8_t g_102 = 0xA3L;
static int16_t g_104[2][10] = {{0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL},{0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL,0x7B0EL}};
static int8_t g_127 = 0xADL;
static int32_t g_131 = (-3L);
static volatile union U0 *g_138 = (void*)0;
static volatile union U0 g_140 = {0UL};/* VOLATILE GLOBAL g_140 */
static int64_t g_145 = 6L;
static int8_t g_147 = 5L;
static uint16_t g_149 = 1UL;
static uint16_t g_169 = 1UL;
static uint32_t g_198 = 0xA87665D8L;
static int32_t g_221 = 0x0B1BDB07L;
static uint16_t g_222 = 65526UL;
static union U0 g_289 = {252UL};/* VOLATILE GLOBAL g_289 */
static union U0 *g_288 = &g_289;
static union U0 **g_287 = &g_288;
static int16_t g_295 = 0xE4E2L;
static uint64_t g_312 = 0UL;
static uint64_t g_315[2][8][9] = {{{18446744073709551614UL,0x7D44FB6F4A190B2BLL,0UL,0x997E5DB754613F60LL,0UL,0x997E5DB754613F60LL,0UL,0x7D44FB6F4A190B2BLL,18446744073709551614UL},{2UL,0xA29A4AC84FFCF1D4LL,2UL,1UL,0UL,0x0675B026C55A2888LL,7UL,0x690B895AD1BCB1F4LL,1UL},{0x0675B026C55A2888LL,1UL,18446744073709551606UL,1UL,0UL,2UL,0x2EAF816F9A348AB5LL,0xC66CCFA5AEBE9E31LL,0x679ECC25BD6D65A8LL},{2UL,0UL,7UL,18446744073709551606UL,0xCC78ED14C3474528LL,0x40D8EDE5B9BBD235LL,0x690B895AD1BCB1F4LL,1UL,0xCEBB0EE1BF02F135LL},{18446744073709551614UL,0x679ECC25BD6D65A8LL,0xAD8A633CF6F25CD8LL,0x3F887DAB1DE77E4BLL,1UL,0xCEBB0EE1BF02F135LL,0UL,0x5150DD777C955335LL,0UL},{7UL,0x679ECC25BD6D65A8LL,0x40D8EDE5B9BBD235LL,0x6864C590541D072FLL,7UL,0xAD8A633CF6F25CD8LL,7UL,0x6864C590541D072FLL,0x40D8EDE5B9BBD235LL},{0UL,0UL,1UL,0x40D8EDE5B9BBD235LL,0x2EAF816F9A348AB5LL,1UL,0x3F887DAB1DE77E4BLL,0xFDCD4D2746254181LL,0xCF45954D822B14FDLL},{0x2EAF816F9A348AB5LL,1UL,0UL,7UL,0x679ECC25BD6D65A8LL,0x3F887DAB1DE77E4BLL,1UL,0UL,18446744073709551606UL}},{{0x77FBA8FC994EAE74LL,0xA29A4AC84FFCF1D4LL,1UL,1UL,2UL,0x40D8EDE5B9BBD235LL,18446744073709551606UL,0xC2ADA193FA8DC894LL,1UL},{0UL,1UL,0UL,0x997E5DB754613F60LL,1UL,0UL,2UL,0UL,0x679ECC25BD6D65A8LL},{1UL,0UL,0UL,0x997E5DB754613F60LL,0x77FBA8FC994EAE74LL,0xCEBB0EE1BF02F135LL,0x2BCDFAA73AA586F3LL,0xCEBB0EE1BF02F135LL,0x77FBA8FC994EAE74LL},{1UL,0x6864C590541D072FLL,0x6864C590541D072FLL,1UL,0x2BCDFAA73AA586F3LL,0x679ECC25BD6D65A8LL,1UL,18446744073709551614UL,1UL},{0xAD8A633CF6F25CD8LL,0xC510BFA6F946EF15LL,0x679ECC25BD6D65A8LL,0x7D44FB6F4A190B2BLL,0UL,1UL,7UL,0x5150DD777C955335LL,0UL},{0xCC78ED14C3474528LL,0x5150DD777C955335LL,0x2EAF816F9A348AB5LL,0UL,0x2BCDFAA73AA586F3LL,18446744073709551614UL,0x0675B026C55A2888LL,2UL,1UL},{6UL,1UL,7UL,2UL,0x77FBA8FC994EAE74LL,0xAD8A633CF6F25CD8LL,0UL,7UL,0x3FFB475F5708CA35LL},{0xFDCD4D2746254181LL,0xA29A4AC84FFCF1D4LL,1UL,0xCF45954D822B14FDLL,1UL,0xAD8A633CF6F25CD8LL,0x5150DD777C955335LL,6UL,0x5150DD777C955335LL}}};
static union U0 g_340 = {249UL};/* VOLATILE GLOBAL g_340 */
static int32_t *g_345 = &g_21;
static int32_t g_363 = (-1L);
static uint16_t g_366 = 65535UL;
static const uint64_t g_400 = 1UL;
static const uint64_t g_402 = 1UL;
static uint8_t g_423 = 0xA6L;
static int64_t g_459 = 0x0946C30C0CB181AELL;
static uint32_t g_470 = 18446744073709551615UL;
static const int8_t g_546[8][10] = {{(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L)},{0L,0L,0x24L,0L,0L,0x24L,0L,0L,0x24L,0L},{0L,(-10L),(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L),0L},{(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L)},{0L,0L,0x24L,0L,0L,0x24L,0L,0L,0x24L,0L},{0L,(-10L),(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L),0L},{(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L),0L,(-10L),(-10L)},{0L,0L,0x24L,0L,0L,0x24L,0L,0L,0x24L,0L}};
static volatile uint64_t g_599 = 9UL;/* VOLATILE GLOBAL g_599 */
static volatile uint64_t * volatile g_598 = &g_599;/* VOLATILE GLOBAL g_598 */
static volatile uint64_t * volatile *g_597 = &g_598;
static int16_t g_615 = 0xE088L;
static int16_t g_625 = 1L;
static uint64_t *g_648 = &g_312;
static uint64_t **g_647 = &g_648;
static uint64_t g_697[5][7] = {{0x65673DF16D860CF9LL,0xAE44D1852E930FD7LL,0x65673DF16D860CF9LL,0x8E68DCEC0575F561LL,0xD81341BF4783345DLL,0xD81341BF4783345DLL,0x8E68DCEC0575F561LL},{0xE51DA86717C94C22LL,0xCC1C3E0866E7B53FLL,0xE51DA86717C94C22LL,0x813580966C06B988LL,18446744073709551614UL,18446744073709551614UL,0x813580966C06B988LL},{0x65673DF16D860CF9LL,0xAE44D1852E930FD7LL,0x65673DF16D860CF9LL,0x8E68DCEC0575F561LL,0xD81341BF4783345DLL,0xD81341BF4783345DLL,0x8E68DCEC0575F561LL},{0xE51DA86717C94C22LL,0xCC1C3E0866E7B53FLL,0xE51DA86717C94C22LL,0x813580966C06B988LL,18446744073709551614UL,18446744073709551614UL,0x813580966C06B988LL},{0x65673DF16D860CF9LL,0xAE44D1852E930FD7LL,0x65673DF16D860CF9LL,0x8E68DCEC0575F561LL,0xD81341BF4783345DLL,0xD81341BF4783345DLL,0x8E68DCEC0575F561LL}};
static const union U0 g_731 = {0x16L};/* VOLATILE GLOBAL g_731 */
static int16_t **g_794[10] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t **g_894 = &g_13;
static int32_t ***g_893 = &g_894;
static int32_t * const *g_987 = (void*)0;
static int32_t * const **g_986 = &g_987;
static uint16_t g_1033 = 0x082AL;
static int64_t g_1048 = (-1L);
static union U0 ***g_1055 = &g_287;
static uint16_t g_1063 = 0x4ADEL;
static int16_t g_1098 = 0xA07EL;
static uint32_t g_1164 = 4UL;
static int8_t *g_1247 = &g_90.f1;
static int64_t *g_1282[8] = {&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67,&g_67};
static const volatile int32_t *g_1288 = (void*)0;
static union U0 g_1322 = {0x8EL};/* VOLATILE GLOBAL g_1322 */
static union U0 ****g_1353 = &g_1055;
static uint16_t g_1355 = 0x7D8AL;
static const int64_t g_1371[9] = {0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL,0xD46DFED9E668FB40LL};
static uint32_t g_1374 = 1UL;
static int8_t g_1381 = 0x69L;
static union U0 g_1386 = {0xE0L};/* VOLATILE GLOBAL g_1386 */
static const uint32_t g_1414 = 6UL;
static const int32_t *g_1448 = &g_14;
static const int32_t **g_1447 = &g_1448;
static const int32_t ***g_1446 = &g_1447;
static const int32_t ****g_1445 = &g_1446;
static uint8_t g_1500 = 0x45L;
static volatile uint32_t g_1539[5] = {0xDCFBCC3DL,0xDCFBCC3DL,0xDCFBCC3DL,0xDCFBCC3DL,0xDCFBCC3DL};
static volatile uint32_t * const  volatile g_1538 = &g_1539[2];/* VOLATILE GLOBAL g_1538 */
static volatile uint32_t * const  volatile *g_1537 = &g_1538;
static uint8_t g_1587 = 0x97L;
static union U0 g_1592[8][5][6] = {{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{255UL},{255UL},{254UL}},{{0xE6L},{254UL},{0x8CL},{254UL},{0xE6L},{0x3AL}},{{2UL},{254UL},{252UL},{255UL},{255UL},{255UL}}},{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{255UL},{255UL},{254UL}},{{0xE6L},{254UL},{0x8CL},{254UL},{0xE6L},{0x3AL}},{{2UL},{254UL},{252UL},{255UL},{255UL},{255UL}}},{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{255UL},{255UL},{254UL}},{{0xE6L},{254UL},{0x8CL},{254UL},{0xE6L},{0x3AL}},{{2UL},{254UL},{252UL},{255UL},{255UL},{255UL}}},{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{255UL},{255UL},{254UL}},{{0xE6L},{254UL},{0x8CL},{254UL},{0xE6L},{0x3AL}},{{2UL},{254UL},{252UL},{255UL},{255UL},{255UL}}},{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{255UL},{255UL},{254UL}},{{0xE6L},{254UL},{0x8CL},{254UL},{0xE6L},{0x3AL}},{{2UL},{254UL},{252UL},{255UL},{255UL},{255UL}}},{{{2UL},{0x00L},{2UL},{254UL},{252UL},{255UL}},{{0xE6L},{0x3AL},{252UL},{255UL},{252UL},{0x3AL}},{{252UL},{0x00L},{0x8CL},{0x00L},{0xE6L},{255UL}},{{252UL},{255UL},{255UL},{255UL},{252UL},{254UL}},{{0x8CL},{255UL},{2UL},{255UL},{0xE6L},{255UL}}},{{{0x8CL},{0x3AL},{0x8CL},{255UL},{2UL},{255UL}},{{252UL},{254UL},{2UL},{0x00L},{2UL},{254UL}},{{2UL},{0x3AL},{255UL},{0x00L},{0xE6L},{255UL}},{{252UL},{255UL},{255UL},{255UL},{252UL},{254UL}},{{0x8CL},{255UL},{2UL},{255UL},{0xE6L},{255UL}}},{{{0x8CL},{0x3AL},{0x8CL},{255UL},{2UL},{255UL}},{{252UL},{254UL},{2UL},{0x00L},{2UL},{254UL}},{{2UL},{0x3AL},{255UL},{0x00L},{0xE6L},{255UL}},{{252UL},{255UL},{255UL},{255UL},{252UL},{254UL}},{{0x8CL},{255UL},{2UL},{255UL},{0xE6L},{255UL}}}};
static union U0 g_1601 = {0UL};/* VOLATILE GLOBAL g_1601 */
static int8_t g_1634[10] = {1L,(-8L),1L,1L,(-8L),1L,1L,(-8L),1L,1L};
static int8_t g_1635 = 0xD2L;
static int16_t g_1638 = (-1L);
static uint16_t g_1639 = 0x09E3L;
static uint32_t g_1645 = 0x9EFAC375L;
static uint32_t *g_1750 = &g_69;
static volatile int64_t g_1893 = 0x8B032C611B2BFBFBLL;/* VOLATILE GLOBAL g_1893 */
static volatile int64_t *g_1892 = &g_1893;
static volatile int64_t * volatile * const g_1891 = &g_1892;
static volatile int64_t * volatile * const *g_1890 = &g_1891;
static int32_t g_1923 = 0L;
static uint64_t g_1926 = 1UL;
static const union U0 g_1982 = {255UL};/* VOLATILE GLOBAL g_1982 */
static int32_t ****g_1986 = &g_893;
static int32_t *****g_1985 = &g_1986;
static int32_t * const ** const *g_1989 = &g_986;
static int32_t * const ** const **g_1988 = &g_1989;
static int32_t g_2100 = 0xBF845A3EL;
static union U0 g_2113[5] = {{0xF4L},{0xF4L},{0xF4L},{0xF4L},{0xF4L}};
static int16_t * const g_2117 = &g_295;
static int16_t * const *g_2116 = &g_2117;
static int16_t * const **g_2115 = &g_2116;
static int16_t * const ***g_2114 = &g_2115;
static uint32_t *g_2161 = &g_62[4][3];
static uint32_t **g_2160 = &g_2161;
static int32_t ** volatile g_2171[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** volatile g_2173 = (void*)0;/* VOLATILE GLOBAL g_2173 */
static int32_t ** volatile g_2174 = &g_345;/* VOLATILE GLOBAL g_2174 */
static uint16_t g_2221[2] = {0x828EL,0x828EL};
static int32_t g_2253 = 1L;
static uint8_t *g_2255 = &g_1587;
static uint8_t ** volatile g_2254[9][1] = {{&g_2255},{(void*)0},{&g_2255},{(void*)0},{&g_2255},{(void*)0},{&g_2255},{(void*)0},{&g_2255}};
static volatile union U0 g_2331 = {255UL};/* VOLATILE GLOBAL g_2331 */
static uint32_t g_2428 = 1UL;
static int16_t g_2467 = 0xA6C4L;
static int64_t g_2488 = 0x272B524A351CD2B3LL;
static union U0 g_2515 = {255UL};/* VOLATILE GLOBAL g_2515 */
static const int16_t **g_2591 = (void*)0;
static const int16_t ***g_2590 = &g_2591;
static uint8_t g_2600 = 0xD9L;
static int32_t g_2616 = 1L;
static int64_t **g_2622 = &g_1282[5];
static int64_t ***g_2621 = &g_2622;
static int64_t ****g_2620 = &g_2621;
static uint16_t g_2650 = 65535UL;


/* --- FORWARD DECLARATIONS --- */
static const int8_t  func_1(void);
static int32_t * func_2(int32_t  p_3, int32_t * p_4, int32_t * p_5);
static int32_t  func_6(int32_t * const  p_7, int64_t  p_8);
static int32_t * func_10(uint64_t  p_11, uint8_t  p_12);
static int16_t  func_15(const int32_t  p_16, uint16_t  p_17);
static int32_t * func_29(int32_t ** p_30);
static uint16_t  func_37(uint64_t  p_38, int32_t * p_39, int64_t  p_40, uint32_t  p_41);
static int32_t  func_42(int8_t  p_43, int32_t * p_44);
static int32_t  func_50(int64_t  p_51, int32_t * p_52, int8_t  p_53, const int32_t ** p_54);
static int64_t  func_70(uint64_t  p_71);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_9 g_13 g_14 g_23 g_893 g_894 g_1446 g_1447 g_1645 g_1322.f1 g_21 g_1926 g_1164 g_198 g_459 g_66 g_647 g_648 g_1371 g_1247 g_90.f1 g_1634 g_149 g_1055 g_287 g_1386.f2 g_546 g_93.f1 g_731.f1 g_1988 g_312 g_345 g_1601.f1 g_1986 g_69 g_289.f1 g_221 g_400 g_1386.f1 g_340.f1 g_1355 g_102 g_1635 g_1985 g_1445 g_1923 g_1587 g_423 g_1048 g_2100 g_288 g_2114 g_2116 g_2117 g_295 g_2115 g_1592.f2 g_615 g_145 g_1448 g_315 g_2174 g_90.f3 g_2161 g_1890 g_1891 g_1892 g_1893 g_2221 g_131 g_1989 g_289 g_62 g_1982.f2 g_104 g_2254 g_169 g_1353 g_598 g_599 g_2331 g_1537 g_1538 g_93.f2 g_697 g_2255 g_1539 g_1638 g_222 g_597 g_2590 g_363 g_2600 g_2616 g_2620 g_2650 g_1374
 * writes: g_14 g_23 g_21 g_1448 g_1645 g_1322.f1 g_1926 g_1164 g_198 g_459 g_1985 g_102 g_90.f1 g_312 g_66 g_1355 g_1587 g_1923 g_127 g_423 g_894 g_366 g_2114 g_315 g_2160 g_345 g_289.f1 g_647 g_62 g_1500 g_2100 g_295 g_131 g_145 g_221 g_2253 g_288 g_1592.f2 g_1063 g_222 g_1048 g_67 g_2590 g_2115 g_697 g_149
 */
static const int8_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_18 = 0UL;
    int32_t *l_2223 = &g_131;
    int16_t *l_2367[6] = {&g_104[1][9],&g_104[1][6],&g_104[1][6],&g_104[1][9],&g_104[1][6],&g_104[1][6]};
    int32_t l_2368 = (-7L);
    int32_t l_2369 = 6L;
    uint8_t l_2391[5] = {0UL,0UL,0UL,0UL,0UL};
    uint32_t l_2409 = 0xB680E7E7L;
    uint16_t l_2443 = 0xC871L;
    int8_t **l_2477 = &g_1247;
    uint32_t l_2490 = 1UL;
    int32_t l_2494 = (-10L);
    int32_t l_2564 = 0x74D09FD2L;
    union U0 **l_2573 = (void*)0;
    uint64_t l_2592 = 0x9EC509732C931E2CLL;
    uint32_t l_2614 = 0UL;
    int64_t ****l_2624[3][5] = {{&g_2621,&g_2621,&g_2621,&g_2621,&g_2621},{&g_2621,&g_2621,&g_2621,&g_2621,(void*)0},{&g_2621,&g_2621,&g_2621,&g_2621,&g_2621}};
    int64_t l_2668 = 0x74A6889F7E4694AFLL;
    int i, j;
    (**g_1446) = func_2((func_6((g_9 , func_10(g_9, ((g_13 == &g_14) == func_15((*g_13), l_18)))), ((l_18 | 0x520BFDDAL) , l_18)) , (*g_13)), l_2223, &g_221);
    if ((!(safe_mod_func_uint8_t_u_u((safe_rshift_func_int16_t_s_s(((safe_mul_func_uint16_t_u_u((safe_add_func_uint32_t_u_u((((((*g_13) && ((**g_894) = ((((*l_2223) == (((l_2369 = ((safe_mul_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((*l_2223), (*l_2223))), (safe_add_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_s((((***g_2115) = (****g_2114)) & (safe_rshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((safe_div_func_int32_t_s_s((((((void*)0 == (*g_1537)) <= (*l_2223)) != (l_2368 ^= ((*l_2223) , (-7L)))) , 0xCF38922BL), (-1L))), (*l_2223))), (*l_2223))), 4))), (*g_1247))), g_93[6].f2)))) < 0xA4C83E3EL)) & 0x025DL) | 0x4EL)) > (*g_648)) ^ 0x5F79L))) , 0x9620L) & (*l_2223)) < (*l_2223)), 0UL)), 0x73B7L)) > 0L), 11)), 0x4BL))))
    { /* block id: 1231 */
        int64_t l_2379[3][10] = {{(-1L),(-1L),1L,(-10L),1L,(-1L),(-1L),1L,(-10L),1L},{(-1L),(-1L),1L,(-10L),1L,(-1L),(-1L),1L,(-10L),1L},{(-1L),(-1L),1L,(-10L),1L,(-1L),(-1L),1L,(-10L),1L}};
        int32_t l_2386 = 0xE40FB64DL;
        int32_t l_2390 = 0x8118BE57L;
        int32_t l_2394 = (-3L);
        int8_t l_2406 = (-1L);
        int32_t l_2444 = 7L;
        uint16_t l_2459 = 65535UL;
        int64_t **l_2475 = &g_1282[5];
        int64_t ***l_2474 = &l_2475;
        uint32_t l_2484 = 0UL;
        int32_t l_2489 = 8L;
        uint32_t *l_2516 = &g_62[0][3];
        int16_t *** const l_2523 = &g_794[8];
        int16_t *** const *l_2522 = &l_2523;
        int16_t *** const **l_2521 = &l_2522;
        uint8_t l_2524 = 0x94L;
        int i, j;
        for (g_312 = 0; (g_312 != 22); ++g_312)
        { /* block id: 1234 */
            uint16_t l_2389[5];
            uint32_t *l_2392 = (void*)0;
            uint32_t *l_2393[5] = {&g_1645,&g_1645,&g_1645,&g_1645,&g_1645};
            int32_t l_2407 = 0x7441EB14L;
            int32_t l_2449 = 0xA4324FA1L;
            int16_t l_2493 = (-1L);
            uint32_t l_2512 = 18446744073709551615UL;
            int i;
            for (i = 0; i < 5; i++)
                l_2389[i] = 0x2E9EL;
            (**g_1446) = func_10((((*g_2161) & (l_2394 = (l_2391[4] = (safe_lshift_func_int16_t_s_u((safe_unary_minus_func_uint32_t_u(((((l_2390 = ((safe_rshift_func_uint8_t_u_s(((!l_2379[2][0]) >= ((!(((l_2386 = (safe_div_func_uint32_t_u_u(((void*)0 != (*g_2115)), (safe_sub_func_int32_t_s_s((safe_lshift_func_int16_t_s_s((*l_2223), l_2379[2][0])), (*g_2161)))))) & ((safe_mul_func_int8_t_s_s((l_2389[0] ^ ((*g_1537) != &g_470)), l_2389[0])) && (*g_598))) , 255UL)) < (*g_1247))), 6)) | 0xE87BD1118E5DDAC3LL)) ^ (*l_2223)) || (*g_1892)) > (*l_2223)))), 8))))) & (*g_2161)), l_2389[3]);
            for (g_21 = 17; (g_21 > (-25)); g_21 = safe_sub_func_uint64_t_u_u(g_21, 1))
            { /* block id: 1242 */
                int8_t *l_2403 = &g_1381;
                int32_t l_2408[7][4][1] = {{{0xDC89D413L},{(-1L)},{(-2L)},{(-2L)}},{{(-2L)},{(-1L)},{0xDC89D413L},{(-1L)}},{{(-2L)},{(-2L)},{(-2L)},{(-1L)}},{{0xDC89D413L},{(-1L)},{(-2L)},{(-2L)}},{{(-2L)},{(-1L)},{0xDC89D413L},{(-1L)}},{{0xDC89D413L},{0xD4676601L},{0xDC89D413L},{(-2L)}},{{0x8590A2DCL},{(-2L)},{0xDC89D413L},{0xD4676601L}}};
                uint32_t *l_2514[10][4][6] = {{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}},{{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]},{(void*)0,&g_66[6][2],(void*)0,&g_66[6][2],(void*)0,&g_66[6][2]},{&g_1164,&g_66[6][2],&g_1164,&g_66[6][2],&g_1164,&g_66[6][2]}}};
                int i, j, k;
            }
        }
    }
    else
    { /* block id: 1300 */
        int32_t * const * const l_2531 = (void*)0;
        uint32_t l_2532 = 0x12ACB17DL;
        uint64_t l_2552 = 0x03656348826536B9LL;
        int8_t l_2563 = 0xB6L;
        int32_t l_2567 = (-5L);
        for (g_145 = 1; (g_145 <= 4); g_145 += 1)
        { /* block id: 1303 */
            int32_t l_2533 = 0x1768A962L;
            uint16_t *l_2555 = (void*)0;
            uint16_t *l_2556[10][6] = {{&g_2221[0],&g_2221[0],(void*)0,&g_149,(void*)0,&g_149},{&g_149,(void*)0,&g_149,(void*)0,&g_2221[0],&g_2221[0]},{(void*)0,&g_366,&g_2221[0],&g_1033,(void*)0,&g_1033},{(void*)0,&g_222,&g_169,&g_1033,&g_1639,(void*)0},{(void*)0,&g_1639,(void*)0,(void*)0,&g_366,&g_366},{&g_149,&g_366,&g_366,&g_149,&g_169,&g_2221[1]},{&g_2221[0],(void*)0,&g_149,&g_2221[0],&g_1355,(void*)0},{&g_1033,&g_366,&g_1639,&g_169,&g_1355,&l_2443},{(void*)0,(void*)0,&g_169,(void*)0,&g_169,(void*)0},{&g_366,&g_366,&l_2443,&g_366,&g_366,&g_1639}};
            const int32_t l_2565 = 0xA365C64FL;
            int64_t *l_2566 = &g_459;
            const int64_t ****l_2568 = (void*)0;
            union U0 ***l_2574 = &l_2573;
            uint64_t *l_2580 = &g_312;
            int16_t ***l_2589 = (void*)0;
            int i, j;
            for (l_2443 = 0; (l_2443 <= 4); l_2443 += 1)
            { /* block id: 1306 */
                int i, j;
                l_2533 ^= (g_697[g_145][(l_2443 + 2)] >= (safe_lshift_func_uint8_t_u_u(((((!0x6DE6L) , ((*g_2255)--)) , ((*g_2255) |= g_1539[g_145])) , 0xC9L), (((((((safe_div_func_uint32_t_u_u((((*g_893) = (*g_893)) != l_2531), (**g_1447))) & 0xBFL) ^ g_23) , g_697[g_145][(l_2443 + 2)]) , l_2532) >= g_1638) || (*l_2223)))));
            }
            l_2567 ^= ((**g_894) = (g_1539[g_145] == ((*l_2566) = (safe_sub_func_uint32_t_u_u(((((safe_rshift_func_int8_t_s_s((*g_1247), (safe_lshift_func_int16_t_s_s(((!(safe_sub_func_int8_t_s_s((safe_mul_func_uint8_t_u_u((((*l_2223) |= ((void*)0 != &g_2114)) >= ((safe_add_func_uint64_t_u_u((safe_div_func_int8_t_s_s((safe_add_func_uint32_t_u_u(((*g_2161)--), l_2552)), (*g_1247))), 0xD7205DC7A8716380LL)) | (safe_rshift_func_uint16_t_u_s((l_2533 = (+0x8AFBL)), ((safe_rshift_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((safe_mod_func_int16_t_s_s((((g_615 >= l_2563) , l_2564) > 4294967295UL), g_1645)), 4)) , &g_149) == &g_1639), 0)) ^ (****g_2114)))))), (*g_1247))), (*g_2255)))) ^ l_2565), 14)))) || (***g_1446)) ^ 4294967295UL) >= (-8L)), (***g_1446))))));
            (**g_1446) = func_10(l_2563, (((void*)0 == l_2568) , (((*g_2161) |= (((safe_rshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s((((g_1539[g_145] <= ((*g_1055) == ((*l_2574) = l_2573))) || (((-8L) < 0x2E9BAC07L) == g_1539[g_145])) < l_2565), l_2565)), g_731.f1)) < l_2565) >= l_2565)) != 0x8EE2B334L)));
            for (g_222 = 0; (g_222 <= 4); g_222 += 1)
            { /* block id: 1323 */
                int8_t l_2593 = 1L;
                int64_t ***l_2618 = (void*)0;
                int64_t ****l_2617 = &l_2618;
                int16_t * const **l_2645 = &g_2116;
                uint32_t l_2658 = 4UL;
                int i, j;
                for (g_1164 = 0; (g_1164 <= 4); g_1164 += 1)
                { /* block id: 1326 */
                    uint64_t **l_2579 = (void*)0;
                    int64_t *l_2587 = &g_1048;
                    int64_t *l_2588 = &g_67;
                    int32_t l_2603 = 0x51384ADFL;
                    const uint16_t *l_2657 = &g_2221[0];
                    union U0 ****l_2671 = &g_1055;
                    int i, j;
                    if ((l_2533 = (g_697[g_1164][(g_222 + 1)] , (((((***g_2115) = l_2565) | (((safe_add_func_int8_t_s_s(((safe_div_func_int16_t_s_s(((l_2580 = l_2566) == (*g_597)), (safe_lshift_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u((18446744073709551615UL ^ ((*l_2588) = ((*l_2587) = ((*l_2566) = (safe_lshift_func_uint8_t_u_s((*g_2255), 2)))))), ((*l_2223) , ((l_2589 == (g_2590 = g_2590)) , l_2592)))) , g_546[0][5]), g_363)))) , l_2593), (*g_1247))) <= (*g_1247)) != l_2593)) , 0xD9A00573L) > l_2593))))
                    { /* block id: 1334 */
                        uint32_t l_2615 = 0UL;
                        int64_t *****l_2619 = &l_2617;
                        int64_t *****l_2623[6][7] = {{&g_2620,&g_2620,&g_2620,(void*)0,&g_2620,(void*)0,&g_2620},{&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620},{&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620},{&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620},{&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620},{&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620,&g_2620}};
                        int i, j;
                        (**g_894) = (safe_sub_func_int32_t_s_s(((safe_mul_func_int16_t_s_s(((safe_mod_func_int16_t_s_s(((****g_2114) = (*l_2223)), g_2600)) > ((safe_sub_func_int64_t_s_s((((+((l_2603 = g_23) <= ((safe_rshift_func_uint16_t_u_u(((!(safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(((l_2615 = ((((void*)0 == &g_2255) <= (safe_mul_func_int8_t_s_s((*g_1247), ((g_66[7][1] = ((((((safe_mul_func_uint8_t_u_u((((*l_2223) && (((*g_2161) = ((((*g_2255) , (((1UL > (**g_1891)) || l_2593) < l_2614)) , (*l_2223)) < (***g_1446))) | (*g_1448))) , 2UL), (*g_1247))) == l_2565) > l_2593) != (*g_345)) && 0x2AL) || g_697[3][4])) , (-1L))))) || 0x6985F9B7L)) ^ 0x7271L), (*l_2223))), 0x8B1BL))) , g_2616), 9)) <= g_697[g_1164][(g_222 + 1)]))) || (***g_1446)) && (*g_648)), g_697[g_1164][(g_222 + 1)])) >= g_315[1][3][2])), l_2593)) && (*l_2223)), (*l_2223)));
                        (*g_345) = ((((*l_2619) = l_2617) == (l_2624[2][2] = g_2620)) || 0x07ADL);
                    }
                    else
                    { /* block id: 1344 */
                        int32_t l_2655[8][4][8] = {{{0xF881D0F1L,0x2428C380L,7L,0L,0x3CA2AFFDL,0xB8D641EDL,0x8561DB7CL,7L},{(-9L),0x7F7F79A5L,0xB360B0A2L,0xD6FF93E1L,0xAD4A6745L,(-9L),1L,0x7F7F79A5L},{7L,0xCD823302L,0xA1ABA7A2L,(-8L),0x60934320L,1L,0xE543B1DFL,0xEAF18C1EL},{0x2BE96265L,0xB7625BCDL,0xB27ABC11L,7L,7L,0xB27ABC11L,0xB7625BCDL,0xA1ABA7A2L}},{{1L,(-9L),1L,0x450DFE5AL,6L,(-3L),0xB27ABC11L,0x8073A813L},{0xB360B0A2L,7L,6L,0x60934320L,0x450DFE5AL,(-3L),0xB360B0A2L,6L},{0xEAF18C1EL,(-9L),(-1L),0xBA8A6151L,1L,(-8L),0xD6FF93E1L,0x87029EDBL},{6L,0x0871164CL,(-4L),0xE19C0BE3L,0x0871164CL,0xB27ABC11L,0xB8D641EDL,0xCD823302L}},{{0xBA8A6151L,0xB8D641EDL,1L,0x87029EDBL,0x450DFE5AL,0x2DC08B43L,0x0871164CL,0x2DC08B43L},{1L,0xD6FF93E1L,0xE543B1DFL,0xD6FF93E1L,1L,7L,(-9L),0x8073A813L},{1L,0xB360B0A2L,0x450DFE5AL,0xE19C0BE3L,0xD6FF93E1L,1L,7L,0xD6FF93E1L},{0xEAF18C1EL,0xB27ABC11L,0x450DFE5AL,0xEAF18C1EL,(-1L),1L,(-9L),6L}},{{0xD6FF93E1L,0x0871164CL,0xE543B1DFL,0x8073A813L,(-1L),(-1L),0x0871164CL,0x60934320L},{0x2DC08B43L,(-1L),1L,0x450DFE5AL,(-9L),0x0BE89F62L,0xB8D641EDL,0xEAF18C1EL},{0xB360B0A2L,0xB27ABC11L,(-4L),0xD6FF93E1L,(-3L),(-3L),0xD6FF93E1L,(-4L)},{6L,6L,(-1L),0xCD823302L,0xD6FF93E1L,7L,0xB360B0A2L,0x87029EDBL}},{{0x2DC08B43L,0x87029EDBL,6L,0x0BE89F62L,0x0871164CL,1L,0xB27ABC11L,0x87029EDBL},{0x87029EDBL,0xB8D641EDL,1L,0xCD823302L,(-1L),6L,0x0871164CL,(-4L)},{0xBA8A6151L,1L,(-8L),0xD6FF93E1L,0x87029EDBL,(-8L),(-1L),0xEAF18C1EL},{1L,0xD6FF93E1L,0xE19C0BE3L,0x450DFE5AL,0xB360B0A2L,1L,0xB27ABC11L,0x60934320L}},{{6L,7L,0x450DFE5AL,0x8073A813L,0x450DFE5AL,7L,6L,6L},{0xA1ABA7A2L,0x87029EDBL,(-1L),0xEAF18C1EL,(-1L),(-8L),0x87029EDBL,0xD6FF93E1L},{6L,(-1L),1L,0xE19C0BE3L,(-1L),0x450DFE5AL,0xB8D641EDL,0x8073A813L},{0xA1ABA7A2L,0xB8D641EDL,0x2DC08B43L,0xD6FF93E1L,0x450DFE5AL,0x0BE89F62L,1L,0x2DC08B43L}},{{6L,(-9L),0xE543B1DFL,0x87029EDBL,0xB360B0A2L,7L,0xD6FF93E1L,0xCD823302L},{1L,1L,6L,0xE19C0BE3L,0x87029EDBL,7L,7L,0x87029EDBL},{0xBA8A6151L,0xB27ABC11L,0xB27ABC11L,0xBA8A6151L,(-1L),0x2DC08B43L,0x87029EDBL,6L},{0x87029EDBL,1L,0xE543B1DFL,0x60934320L,0x0871164CL,(-1L),1L,1L}},{{0xAD4A6745L,(-3L),0xB7625BCDL,0xECF6207FL,0x0BE89F62L,0xAD4A6745L,7L,0xE19C0BE3L},{6L,(-8L),0xF881D0F1L,0x2DC08B43L,0x6724E73CL,(-1L),0x2DC08B43L,0x2428C380L},{0x450DFE5AL,0xB27ABC11L,0xEAF18C1EL,1L,0x2DC08B43L,(-9L),0xB27ABC11L,0x0BE89F62L},{0xAD4A6745L,0x2DC08B43L,(-8L),0xB7625BCDL,1L,0xB7625BCDL,(-8L),0x2DC08B43L}}};
                        int32_t l_2656 = 0xC471D180L;
                        int16_t ****l_2666 = &l_2589;
                        int16_t *****l_2665[1];
                        int16_t ******l_2667 = &l_2665[0];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_2665[i] = &l_2666;
                        l_2656 = (l_2368 = ((safe_sub_func_int32_t_s_s((~0x5724293FL), (safe_mod_func_int32_t_s_s(((*g_345) = ((safe_mul_func_uint16_t_u_u((safe_sub_func_uint8_t_u_u((safe_mul_func_int8_t_s_s((1UL < (+((*l_2223) = (safe_rshift_func_int16_t_s_u(((~((*g_648) = (((((safe_rshift_func_uint8_t_u_s((~(--(*g_2255))), 1)) & (((((((****g_1986) = (((((0x867518D0128BD27CLL >= ((((safe_lshift_func_uint8_t_u_u((safe_div_func_uint16_t_u_u(((((*g_2114) = l_2645) != l_2645) , (safe_lshift_func_int8_t_s_u((safe_sub_func_uint64_t_u_u(((((l_2655[3][2][2] = (g_2650 || (((g_697[g_222][(g_1164 + 1)]++) | ((safe_div_func_uint32_t_u_u((l_2593 , ((*l_2223) | l_2565)), l_2603)) && 0x63L)) , (*g_2161)))) > l_2656) , (***g_1446)) != 0x522AB9F5L), l_2656)), 3))), 65535UL)), 6)) , l_2657) != l_2556[4][2]) , 5UL)) ^ 0x530FD7B66AB21594LL) ^ g_1539[g_145]) && (*g_2161)) & (*l_2223))) == l_2552) >= 0x5A5AL) , (*g_2161)) | l_2603) != 8L)) ^ l_2658) != l_2603) | l_2593))) < (*l_2223)), g_615))))), l_2658)), 1L)), g_1374)) <= (*g_1448))), 3L)))) != 5UL));
                        (*l_2223) = (((*l_2566) = (((((safe_mul_func_int16_t_s_s((safe_div_func_uint16_t_u_u((7L != (((((safe_sub_func_int64_t_s_s(((((g_289.f1 < ((&g_2114 == ((*l_2667) = ((****g_1353) , l_2665[0]))) , ((***l_2645) &= (*l_2223)))) > l_2668) , (safe_sub_func_uint16_t_u_u(((void*)0 != l_2671), l_2603))) >= (*l_2223)), g_697[g_1164][(g_222 + 1)])) < l_2603) > 1UL) < g_62[1][0]) ^ 0x5435ED95L)), 0xEE3AL)), l_2658)) <= l_2603) >= 0xCC80A772BD0AB3AFLL) || 0xABL) < l_2593)) >= 18446744073709551606UL);
                        if (l_2658)
                            continue;
                    }
                    for (g_149 = 0; (g_149 <= 9); g_149 += 1)
                    { /* block id: 1363 */
                        (*l_2223) = ((void*)0 == (**g_2115));
                    }
                }
                return g_697[g_222][g_222];
            }
        }
        (*l_2223) = ((safe_mod_func_uint32_t_u_u(0x6215D7A0L, ((safe_rshift_func_int16_t_s_u((safe_add_func_int32_t_s_s((*l_2223), ((*l_2223) , (**g_894)))), ((safe_sub_func_int8_t_s_s(0xEBL, (safe_sub_func_uint64_t_u_u(((*g_1247) > 0x98L), ((*l_2223) , ((*l_2223) , (*g_648))))))) != (-1L)))) , (-3L)))) <= (**g_1891));
    }
    return (*g_1247);
}


/* ------------------------------------------ */
/* 
 * reads : g_893 g_894 g_13 g_14 g_131 g_1988 g_1989 g_287 g_288 g_289 g_1048 g_2161 g_62 g_2116 g_2117 g_295 g_221 g_145 g_1982.f2 g_2174 g_345 g_102 g_104 g_2254 g_1448 g_1371 g_2115 g_1446 g_1447 g_169 g_289.f1 g_1353 g_1055 g_1445 g_1986 g_648 g_312 g_1247 g_90.f1 g_598 g_599 g_2114 g_2100 g_1891 g_1892 g_1893 g_2331
 * writes: g_14 g_131 g_145 g_2100 g_102 g_221 g_2253 g_295 g_1448 g_288 g_289.f1 g_312 g_90.f1 g_1592.f2 g_1063 g_62
 */
static int32_t * func_2(int32_t  p_3, int32_t * p_4, int32_t * p_5)
{ /* block id: 1151 */
    int16_t l_2224[3][7] = {{8L,0x1784L,6L,6L,0x1784L,8L,0x1784L},{(-1L),0xBACAL,0xBACAL,(-1L),(-2L),(-1L),0xBACAL},{0xBB7EL,0xBB7EL,8L,6L,8L,0xBB7EL,0xBB7EL}};
    int32_t ****l_2234[6][7][4] = {{{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,(void*)0,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893}},{{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{(void*)0,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893}},{{&g_893,&g_893,(void*)0,&g_893},{(void*)0,(void*)0,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{(void*)0,&g_893,(void*)0,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,(void*)0}},{{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{(void*)0,&g_893,&g_893,(void*)0},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893}},{{&g_893,&g_893,&g_893,&g_893},{&g_893,(void*)0,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893}},{{(void*)0,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893},{&g_893,&g_893,(void*)0,&g_893},{&g_893,(void*)0,&g_893,&g_893},{&g_893,&g_893,&g_893,&g_893}}};
    uint32_t l_2264[7][9] = {{0x20F8255DL,1UL,1UL,0x20F8255DL,0UL,1UL,0UL,0UL,0UL},{0UL,0xEA161343L,0xB1A83B90L,0UL,0xB1A83B90L,0xEA161343L,0UL,0xEA161343L,0xB1A83B90L},{0x20F8255DL,0UL,1UL,0UL,0UL,0UL,0UL,1UL,0UL},{4294967290UL,0xEA161343L,9UL,0UL,9UL,0xEA161343L,4294967290UL,0xEA161343L,9UL},{0x20F8255DL,1UL,1UL,0x20F8255DL,0UL,1UL,0UL,0UL,0UL},{0UL,0xEA161343L,0xB1A83B90L,0UL,0xB1A83B90L,0xEA161343L,0UL,0xEA161343L,0xB1A83B90L},{0x20F8255DL,0UL,1UL,0UL,0UL,0UL,0UL,1UL,0UL}};
    int16_t ***l_2266 = (void*)0;
    uint8_t * const l_2267 = &g_102;
    const uint32_t l_2268 = 1UL;
    uint32_t l_2277 = 0UL;
    int16_t ** const *l_2334 = &g_794[3];
    int16_t ** const **l_2333 = &l_2334;
    int16_t ** const ***l_2332 = &l_2333;
    int i, j, k;
lbl_2237:
    (***g_893) |= l_2224[2][2];
    for (g_131 = 1; (g_131 <= 6); g_131 += 1)
    { /* block id: 1155 */
        union U0 *** const l_2227 = &g_287;
        int32_t l_2230 = 0L;
        uint8_t *l_2231 = &g_102;
        int32_t ****l_2232 = &g_893;
        int32_t *****l_2233 = (void*)0;
        uint32_t l_2301 = 18446744073709551615UL;
        uint8_t l_2305 = 0x72L;
        uint64_t l_2312 = 18446744073709551609UL;
        uint32_t l_2322 = 1UL;
        uint64_t l_2324 = 0x9D4B43F2C2D89BA9LL;
        if (((((***g_893) = (safe_sub_func_int64_t_s_s(((void*)0 != l_2227), (((((((safe_mul_func_uint16_t_u_u(((((~l_2230) ^ (((&g_1587 != l_2231) ^ ((l_2234[3][3][0] = l_2232) == (l_2224[2][2] , (*g_1988)))) ^ ((***l_2227) , p_3))) || 1UL) < l_2224[1][2]), g_1048)) , (*g_2161)) , (-1L)) && (**g_2116)) , p_3) , 4UL) >= 0xD5242F88L)))) < (*p_5)) || g_62[0][3]))
        { /* block id: 1158 */
            int8_t l_2265 = 0x53L;
            int32_t l_2292 = 0xAC83DFD5L;
            int8_t l_2304 = 0xC4L;
            uint64_t l_2306 = 2UL;
            int32_t ***l_2319[8];
            uint16_t l_2323 = 6UL;
            int i;
            for (i = 0; i < 8; i++)
                l_2319[i] = &g_894;
            for (g_145 = 0; (g_145 <= 6); g_145 += 1)
            { /* block id: 1161 */
                uint8_t l_2263 = 0x2FL;
                (**g_2174) = (~(safe_rshift_func_uint8_t_u_u(g_1982.f2, 1)));
                if ((*p_4))
                    break;
                for (g_102 = 0; (g_102 <= 1); g_102 += 1)
                { /* block id: 1166 */
                    int32_t *l_2252 = &g_2253;
                    int8_t l_2258[1];
                    union U0 *l_2271 = &g_1322;
                    int i, j;
                    for (i = 0; i < 1; i++)
                        l_2258[i] = 0L;
                    if (g_102)
                        goto lbl_2237;
                    (*p_5) = g_104[g_102][g_145];
                    if (((**g_894) = ((((safe_div_func_uint32_t_u_u((((~(safe_rshift_func_uint16_t_u_u(g_104[g_102][(g_145 + 3)], 12))) >= ((((safe_sub_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(((((*l_2252) = g_104[g_102][(g_145 + 3)]) , (void*)0) != g_2254[7][0]), (safe_mod_func_int8_t_s_s(0x1EL, l_2258[0])))) >= ((((((((l_2265 = ((g_1448 != (((*g_345) = (((***g_2115) |= (safe_lshift_func_int16_t_s_s(((((g_1371[6] || l_2258[0]) <= l_2263) != l_2264[6][7]) || p_3), 8))) >= p_3)) , p_4)) > (*p_5))) , (void*)0) != (**g_1446)) | 6L) , 0xDDL) && 0L) , (void*)0) == l_2266)), g_169)), 0xFDL)) , 0x974BA670L) , (void*)0) != l_2267)) || p_3), l_2268)) && 0x5A688595BD4319EDLL) | l_2263) <= g_289.f1)))
                    { /* block id: 1174 */
                        (**g_894) = (safe_mod_func_uint32_t_u_u(((***g_1353) != l_2271), 0x0E433A03L));
                    }
                    else
                    { /* block id: 1176 */
                        uint64_t l_2272 = 0xEA71B47EE847F1B5LL;
                        (***g_1445) = &p_3;
                        --l_2272;
                        (*g_287) = (*g_287);
                        return (*g_894);
                    }
                    (**g_2174) = (****g_1986);
                }
            }
            for (g_289.f1 = 0; (g_289.f1 <= 1); g_289.f1 += 1)
            { /* block id: 1187 */
                int i, j;
                (*p_5) = (safe_rshift_func_uint16_t_u_s(0UL, 0));
                if (g_104[g_289.f1][g_131])
                    continue;
            }
            if (l_2277)
            { /* block id: 1191 */
                int16_t l_2288 = 0x436CL;
                int8_t *l_2289 = &g_1592[0][4][1].f2;
                int32_t l_2290 = 0x44CCDBB0L;
                uint16_t *l_2291 = &g_1063;
                (*g_13) = ((safe_div_func_int8_t_s_s((((((safe_div_func_uint32_t_u_u(((*g_2161) = (0xE3719B3A445774BCLL && (((l_2292 = ((safe_rshift_func_int8_t_s_s(((((0xB4L || (++(*l_2231))) ^ (((safe_lshift_func_int8_t_s_u(8L, p_3)) && l_2288) , (((*g_648) = (*g_648)) , ((((*l_2291) = ((****l_2232) || (p_3 != (~(((l_2290 &= ((*l_2289) = ((*g_1247) &= 8L))) == p_3) ^ 1L))))) | 0x45E4L) , 0x3549L)))) , 1L) | (*g_598)), 2)) <= l_2265)) , (void*)0) == (void*)0))), l_2265)) < 0x880F444BA10A9C2ELL) > 0xF39848F7L) >= 18446744073709551615UL) , (*g_1247)), l_2265)) ^ l_2265);
                (*g_345) ^= ((safe_div_func_int32_t_s_s(((*p_5) = (((l_2265 | ((safe_add_func_int8_t_s_s((~(*g_1247)), (safe_add_func_int16_t_s_s(0L, (safe_add_func_int64_t_s_s((((((*l_2291) = l_2301) ^ (****g_2114)) && ((0x0609F2DA329370B1LL != (safe_mul_func_uint16_t_u_u(l_2292, p_3))) != ((*l_2289) = ((6L == (*g_1247)) ^ 0x35L)))) <= p_3), p_3)))))) ^ p_3)) > l_2304) <= p_3)), 0xEEB6DAEBL)) ^ 255UL);
                (*p_5) = l_2305;
            }
            else
            { /* block id: 1206 */
                int32_t *l_2309 = &l_2230;
                ++l_2306;
                return (*g_2174);
            }
            (*g_345) = ((safe_mul_func_int16_t_s_s((l_2312 >= (safe_mul_func_uint16_t_u_u(((safe_sub_func_int64_t_s_s((**g_1891), (0x31A7L ^ (0x4B3F2F94L != 1UL)))) && (safe_lshift_func_int16_t_s_s(((void*)0 == l_2319[0]), 1))), p_3))), (+((**g_2116) = ((safe_add_func_uint8_t_u_u(((*l_2231) = (l_2322 < (****l_2232))), p_3)) == 0x9BL))))) > l_2323);
        }
        else
        { /* block id: 1213 */
            return (***g_1986);
        }
        l_2324++;
        for (g_2100 = 5; (g_2100 >= 1); g_2100 -= 1)
        { /* block id: 1219 */
            uint32_t l_2341 = 0UL;
            int64_t l_2342 = 0xA9D6BA44B1C38C66LL;
            (*g_13) = ((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(0xE259L, (g_2331 , ((0L | ((void*)0 != l_2332)) | ((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((((((((safe_rshift_func_int8_t_s_s((*g_1247), (p_3 && ((***g_2115) = (((***g_1055) , 0L) | p_3))))) == p_3) , l_2341) && p_3) || l_2341) < p_3) > (*p_5)), 1)), l_2342)) | (-6L)))))), p_3)) & p_3);
        }
    }
    (*p_4) ^= (*g_345);
    return (**g_893);
}


/* ------------------------------------------ */
/* 
 * reads : g_1986 g_893 g_894 g_13 g_1446 g_1447 g_2174 g_289.f1 g_90.f3 g_2161 g_2114 g_2115 g_2116 g_2117 g_295 g_1890 g_1891 g_1892 g_1893 g_648 g_312 g_1247 g_90.f1 g_345 g_315 g_2100 g_400 g_93.f1 g_2221 g_14
 * writes: g_1448 g_345 g_289.f1 g_647 g_62 g_312 g_1500 g_2100 g_315 g_295 g_14
 */
static int32_t  func_6(int32_t * const  p_7, int64_t  p_8)
{ /* block id: 1132 */
    int32_t **l_2170 = (void*)0;
    int32_t **l_2172 = (void*)0;
    uint64_t **l_2179[5][3][9] = {{{(void*)0,&g_648,&g_648,(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648},{(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648}},{{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,&g_648,(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,&g_648,&g_648,&g_648,(void*)0,(void*)0,&g_648,&g_648,&g_648}},{{(void*)0,&g_648,(void*)0,(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,(void*)0,&g_648}},{{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,(void*)0},{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,(void*)0,&g_648,&g_648},{&g_648,&g_648,&g_648,(void*)0,&g_648,&g_648,&g_648,&g_648,(void*)0}},{{&g_648,&g_648,&g_648,(void*)0,&g_648,&g_648,&g_648,&g_648,&g_648},{&g_648,&g_648,&g_648,&g_648,&g_648,&g_648,(void*)0,&g_648,&g_648},{&g_648,&g_648,&g_648,&g_648,&g_648,(void*)0,&g_648,&g_648,(void*)0}}};
    uint64_t **l_2184 = &g_648;
    int32_t l_2210 = 0x0546D3BBL;
    int32_t l_2211 = (-8L);
    int16_t l_2212 = 0x961FL;
    const int32_t l_2222 = 0xE13F6D79L;
    int i, j, k;
    (**g_1446) = (***g_1986);
    (*g_2174) = p_7;
    for (g_289.f1 = 0; (g_289.f1 == 12); ++g_289.f1)
    { /* block id: 1137 */
        uint64_t ***l_2180 = &l_2179[3][0][0];
        uint64_t ***l_2181 = &g_647;
        uint64_t **l_2183[5][6];
        uint64_t ***l_2182[3][4][4] = {{{&l_2183[4][1],&l_2183[1][2],&l_2183[4][3],&l_2183[4][3]},{&l_2183[4][3],&l_2183[1][2],&l_2183[1][2],&l_2183[4][3]},{&l_2183[1][2],&l_2183[4][3],&l_2183[4][1],&l_2183[4][3]},{&l_2183[1][2],&l_2183[4][1],&l_2183[1][2],&l_2183[4][3]}},{{&l_2183[4][3],&l_2183[4][3],&l_2183[4][3],&l_2183[4][3]},{&l_2183[4][1],&l_2183[4][1],&l_2183[4][3],&l_2183[4][3]},{&l_2183[4][3],&l_2183[4][3],&l_2183[4][3],&l_2183[4][3]},{&l_2183[4][1],&l_2183[1][2],&l_2183[4][3],&l_2183[4][3]}},{{&l_2183[4][3],&l_2183[1][2],&l_2183[1][2],&l_2183[4][3]},{&l_2183[1][2],&l_2183[4][3],&l_2183[4][1],&l_2183[4][3]},{&l_2183[1][2],&l_2183[4][1],&l_2183[1][2],&l_2183[4][3]},{&l_2183[4][3],&l_2183[4][3],&l_2183[4][3],&l_2183[4][3]}}};
        int32_t l_2193 = 0x18D7EEF6L;
        const uint32_t l_2198 = 1UL;
        uint8_t *l_2199 = &g_1500;
        int i, j, k;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 6; j++)
                l_2183[i][j] = &g_648;
        }
        (**g_2174) = (((*l_2199) = (safe_rshift_func_int8_t_s_s(((((*l_2181) = ((*l_2180) = l_2179[3][0][0])) != (l_2184 = (void*)0)) | (g_90.f3 , (safe_mul_func_int8_t_s_s(0xB7L, (((((*g_2161) = 0UL) || (safe_sub_func_uint64_t_u_u(((*g_648) &= (safe_div_func_uint64_t_u_u(((safe_add_func_int64_t_s_s(l_2193, ((safe_rshift_func_int16_t_s_s(1L, (****g_2114))) ^ (((safe_mul_func_int16_t_s_s(0x2ECDL, 1UL)) ^ 0x9FL) == p_8)))) , 0xAC31A49204A13F69LL), (***g_1890)))), 0xB2FEC10312BDD25BLL))) > 0xA5L) == l_2198))))), 7))) >= (*g_1247));
    }
    (**g_894) |= (p_8 & (safe_mod_func_int16_t_s_s((((safe_div_func_int8_t_s_s(((*g_1247) ^ (((*g_2161) = p_8) , ((safe_mod_func_int32_t_s_s((safe_sub_func_int8_t_s_s((-9L), ((safe_sub_func_uint64_t_u_u((*g_648), (g_315[1][3][2]++))) | ((*p_7) > (((((0xE9L > (safe_mul_func_int8_t_s_s((safe_lshift_func_int16_t_s_u((((*g_2117) = (safe_sub_func_int64_t_s_s((((*g_1892) , g_400) | g_93[6].f1), l_2211))) == p_8), 12)), (*g_1247)))) ^ g_2221[0]) == 1L) != p_8) , (*p_7)))))), p_8)) & 2L))), l_2222)) == 0x225A67187884675FLL) & p_8), 0x6D05L)));
    return p_8;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_10(uint64_t  p_11, uint8_t  p_12)
{ /* block id: 1129 */
    int8_t **l_2165 = &g_1247;
    int8_t ***l_2166 = &l_2165;
    int32_t *l_2167[3];
    int i;
    for (i = 0; i < 3; i++)
        l_2167[i] = &g_2100;
    (*l_2166) = l_2165;
    return l_2167[1];
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_14 g_23 g_893 g_894 g_1446 g_1447 g_1322.f1 g_21 g_1926 g_198 g_459 g_66 g_647 g_648 g_1645 g_1371 g_1247 g_90.f1 g_1634 g_149 g_1055 g_287 g_1386.f2 g_546 g_93.f1 g_731.f1 g_1988 g_312 g_345 g_1601.f1 g_1986 g_69 g_289.f1 g_221 g_400 g_1386.f1 g_340.f1 g_1355 g_102 g_1635 g_1985 g_1445 g_423 g_1048 g_2100 g_1587 g_288 g_2114 g_2116 g_2117 g_295 g_2115 g_1592.f2 g_615 g_1923 g_145 g_1448 g_315 g_1164
 * writes: g_14 g_23 g_21 g_1448 g_1645 g_1322.f1 g_1926 g_1164 g_198 g_459 g_1985 g_102 g_90.f1 g_312 g_66 g_1355 g_1587 g_1923 g_127 g_423 g_894 g_366 g_2114 g_315 g_2160
 */
static int16_t  func_15(const int32_t  p_16, uint16_t  p_17)
{ /* block id: 1 */
    int8_t l_19[2][7][10] = {{{1L,0L,(-8L),0L,0L,(-8L),0L,1L,(-10L),0xBBL},{(-1L),0x88L,0x2CL,1L,0x1EL,0L,1L,0xBBL,1L,0L},{0x70L,0x1EL,0x2CL,0x1EL,0x70L,0xBBL,(-10L),1L,0L,(-8L)},{(-10L),(-10L),(-8L),0xBBL,(-3L),0x7DL,0x7DL,(-3L),0xBBL,(-8L)},{0xBBL,0xBBL,0x88L,(-8L),0x70L,0x20L,(-3L),0x2CL,0x11L,0L},{0x2CL,1L,(-3L),0L,0x1EL,0L,(-3L),1L,0x2CL,0xBBL},{(-10L),0xBBL,0x11L,0x70L,0L,(-1L),0x7DL,0x1EL,0x1EL,0x7DL}},{{1L,(-10L),0x70L,0x70L,(-10L),1L,(-10L),(-1L),0x2CL,0x20L},{0x20L,0x1EL,0xBBL,0L,0x11L,0x88L,1L,0x88L,0x11L,0L},{0x20L,0x88L,0x20L,(-8L),0x7DL,1L,0L,0L,0xBBL,(-1L)},{1L,0L,0L,0x2CL,(-8L),(-8L),0x2CL,0x70L,1L,0x1EL},{0x11L,(-10L),0x7DL,0xBBL,0x2CL,1L,(-3L),0L,0x1EL,0L},{1L,0x7DL,0x2CL,(-10L),0x2CL,0x7DL,1L,(-8L),(-1L),0x1EL},{0x2CL,(-3L),0x20L,0x70L,(-8L),0x88L,0xBBL,0xBBL,0x88L,(-8L)}}};
    int32_t l_22[3];
    uint32_t l_1848 = 0x5B81726CL;
    int32_t l_1914 = 1L;
    uint64_t l_1920 = 1UL;
    const int64_t **l_1931 = (void*)0;
    union U0 **l_1939[1];
    int32_t ****l_1984 = &g_893;
    int32_t *****l_1983[8];
    int32_t l_1987 = 0x51D56AC5L;
    int32_t * const ** const **l_1990 = &g_1989;
    int16_t ****l_2119 = (void*)0;
    int8_t l_2131[4] = {8L,8L,8L,8L};
    const int32_t *l_2164 = &g_2100;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_22[i] = 1L;
    for (i = 0; i < 1; i++)
        l_1939[i] = &g_288;
    for (i = 0; i < 8; i++)
        l_1983[i] = &l_1984;
lbl_2162:
    for (g_14 = 0; (g_14 <= 1); g_14 += 1)
    { /* block id: 4 */
        int32_t *l_20[6];
        const int32_t *l_27 = &g_28;
        const int32_t **l_26 = &l_27;
        uint16_t l_1852 = 0x2F99L;
        int32_t *l_1873 = &g_21;
        uint64_t **l_1879 = &g_648;
        int32_t l_1895 = (-1L);
        uint8_t *l_1899 = (void*)0;
        uint8_t **l_1898 = &l_1899;
        uint32_t l_1915 = 1UL;
        union U0 ***l_1936[10][4] = {{(void*)0,&g_287,(void*)0,&g_287},{(void*)0,&g_287,&g_287,(void*)0},{&g_287,&g_287,&g_287,(void*)0},{&g_287,&g_287,&g_287,&g_287},{&g_287,&g_287,&g_287,&g_287},{&g_287,&g_287,&g_287,&g_287},{&g_287,(void*)0,&g_287,&g_287},{&g_287,(void*)0,&g_287,&g_287},{&g_287,&g_287,&g_287,&g_287},{&g_287,&g_287,&g_287,&g_287}};
        int i, j;
        for (i = 0; i < 6; i++)
            l_20[i] = &g_21;
        if ((*g_13))
            break;
        g_23++;
        g_21 = (((*l_26) = (void*)0) != (void*)0);
        for (p_17 = 0; (p_17 <= 1); p_17 += 1)
        { /* block id: 11 */
            int16_t **l_1832 = (void*)0;
            int8_t **l_1847 = &g_1247;
            int8_t ***l_1846[9] = {&l_1847,&l_1847,&l_1847,&l_1847,&l_1847,&l_1847,&l_1847,&l_1847,&l_1847};
            int32_t l_1849 = (-1L);
            const int64_t l_1863[1] = {0x0E8AF403F3F72DAALL};
            uint32_t l_1864 = 1UL;
            int32_t l_1872 = 0L;
            uint64_t **l_1900 = &g_648;
            int32_t l_1924 = 0x4834BDFCL;
            int32_t l_1925 = 4L;
            int32_t l_1940 = 0x2F611DCFL;
            int i;
            for (g_23 = 0; (g_23 <= 1); g_23 += 1)
            { /* block id: 14 */
                int32_t **l_31 = &l_20[1];
                uint16_t l_1845 = 0xBE0CL;
                int32_t l_1851 = (-2L);
            }
            (**g_1446) = (**g_893);
            for (g_1645 = 0; (g_1645 <= 1); g_1645 += 1)
            { /* block id: 987 */
                uint32_t l_1917 = 0xD69A66A9L;
                int32_t *l_1921 = (void*)0;
                int32_t l_1922 = 0x858F8FEBL;
                for (l_1872 = 0; (l_1872 <= 1); l_1872 += 1)
                { /* block id: 990 */
                    for (g_1322.f1 = 1; (g_1322.f1 >= 0); g_1322.f1 -= 1)
                    { /* block id: 993 */
                        int32_t **l_1916 = (void*)0;
                        int i, j, k;
                        (*g_1447) = (**g_893);
                        if (l_19[g_14][(p_17 + 2)][(g_1322.f1 + 5)])
                            continue;
                        l_1917++;
                        (*l_1873) |= l_1920;
                    }
                }
                (**g_1446) = l_1921;
                ++g_1926;
            }
            (*l_1873) = ((safe_mod_func_int64_t_s_s((p_16 | ((l_1931 != (void*)0) , (((safe_div_func_int32_t_s_s(((safe_lshift_func_int16_t_s_s(((((void*)0 == l_1936[7][1]) != p_16) == ((safe_add_func_int16_t_s_s(((void*)0 == l_1939[0]), 0xE63FL)) , p_17)), l_22[0])) , 0x19B32786L), p_17)) == l_1940) ^ 0x8EA5L))), l_1924)) || l_1920);
            for (g_1164 = 0; (g_1164 <= 1); g_1164 += 1)
            { /* block id: 1007 */
                (*g_1447) = &l_1940;
            }
        }
    }
    for (p_17 = 2; (p_17 <= 6); p_17 += 1)
    { /* block id: 1014 */
        uint64_t l_1951 = 18446744073709551606UL;
        int16_t *l_1954[4] = {&g_615,&g_615,&g_615,&g_615};
        uint64_t l_1955 = 0UL;
        const union U0 *l_1981 = &g_1982;
        const union U0 **l_1980 = &l_1981;
        uint8_t *l_1991 = (void*)0;
        uint8_t *l_1992 = &g_102;
        const int32_t l_2018 = 0xB48EFF70L;
        int8_t l_2029 = 0xC3L;
        int64_t **l_2051 = (void*)0;
        int32_t l_2163 = 0x98A861ACL;
        int i;
        for (g_198 = 0; (g_198 <= 2); g_198 += 1)
        { /* block id: 1017 */
            int16_t l_1949 = 0xEBE9L;
            int i;
            l_22[g_198] = (-1L);
            (**g_894) = 0L;
            for (g_459 = 6; (g_459 >= 2); g_459 -= 1)
            { /* block id: 1022 */
                int i, j;
                (*g_13) = ((safe_rshift_func_uint8_t_u_s((safe_sub_func_uint8_t_u_u(((((g_66[(g_198 + 7)][g_459] , (*g_647)) != ((((p_17 <= g_1645) , ((((safe_mul_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_u(((l_1949 , ((1UL != ((&g_1247 == &g_1247) , 0UL)) , g_1371[6])) , p_16), 2)), l_22[g_198])) , (*g_1247)) > g_1634[6]) & 0x94L)) , 0x86861CD7L) , (void*)0)) != 0xDB1284EA02F32E77LL) , g_149), (*g_1247))), 6)) | 0L);
                for (g_1322.f1 = 5; (g_1322.f1 >= 1); g_1322.f1 -= 1)
                { /* block id: 1026 */
                    int32_t *l_1950[3][9][7] = {{{(void*)0,&g_14,&g_21,&g_131,&g_131,&l_22[2],&g_131},{(void*)0,&g_363,(void*)0,&l_22[2],&l_1914,&l_22[2],&l_22[1]},{&g_131,(void*)0,&g_221,&g_363,(void*)0,(void*)0,(void*)0},{(void*)0,&l_22[2],&g_221,&g_21,&g_14,(void*)0,&g_221},{(void*)0,&l_22[g_198],(void*)0,&g_14,(void*)0,&g_363,&g_221},{(void*)0,&g_21,&g_21,&g_1923,&l_1914,(void*)0,(void*)0},{&l_22[1],&l_22[g_198],&g_131,&g_1923,&g_131,&l_22[g_198],&l_22[1]},{&l_1914,&l_22[2],&g_21,&g_14,&g_363,(void*)0,&g_131},{&l_1914,(void*)0,&g_363,&g_21,&g_21,&g_363,&l_1914}},{{&l_22[1],&g_363,&g_21,&g_363,&g_21,(void*)0,&l_22[g_198]},{(void*)0,&g_14,&g_131,&l_22[2],&g_363,(void*)0,&l_1914},{(void*)0,&g_14,&g_21,&g_131,&g_131,&l_22[2],&g_131},{(void*)0,&g_363,(void*)0,&l_22[2],&l_1914,&l_22[2],&l_22[1]},{&g_131,(void*)0,&g_221,&g_363,(void*)0,&l_22[1],&g_363},{&g_363,&l_1914,&g_1923,&l_22[g_198],&g_221,(void*)0,&l_22[1]},{&l_1914,&g_131,&g_221,&g_21,&l_1914,(void*)0,&l_22[1]},{&l_22[2],&g_221,(void*)0,(void*)0,(void*)0,(void*)0,&g_363},{&g_131,&g_131,&g_14,(void*)0,&g_14,&g_131,&g_131}},{{&g_363,&l_1914,&l_22[0],&g_21,(void*)0,(void*)0,&g_1923},{&g_363,&l_1914,(void*)0,&l_22[g_198],(void*)0,(void*)0,&g_131},{&g_131,(void*)0,&l_22[0],&g_131,(void*)0,(void*)0,&l_22[2]},{&l_22[2],&g_131,&g_14,&g_21,(void*)0,&l_22[1],&g_131},{&l_1914,&g_131,(void*)0,&l_22[g_198],&g_14,&l_1914,&g_1923},{&g_363,(void*)0,&g_221,&g_21,(void*)0,&l_1914,&g_131},{&g_1923,&l_1914,&g_1923,&g_131,&l_1914,&l_22[1],&g_363},{&g_363,&l_1914,&g_1923,&l_22[g_198],&g_221,(void*)0,&l_22[1]},{&l_1914,&g_131,&g_221,&g_21,&l_1914,(void*)0,&l_22[1]}}};
                    int i, j, k;
                    --l_1951;
                }
            }
        }
        if (((l_1955 = (-3L)) , ((****g_1986) = (safe_mul_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((safe_mul_func_uint8_t_u_u(((*l_1992) = (safe_add_func_int64_t_s_s(((safe_lshift_func_int8_t_s_u((((((safe_div_func_uint8_t_u_u(((l_1990 = ((safe_div_func_int64_t_s_s(p_16, (safe_sub_func_uint8_t_u_u((((((safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s(0x42075B68D08841C5LL, ((&g_1381 != (void*)0) , 0x3A9A6073A2C2670ALL))), ((((safe_lshift_func_uint16_t_u_u((((l_22[2] = ((*g_1055) != l_1980)) <= ((g_1985 = l_1983[1]) != &g_1986)) || g_1386.f2), g_546[0][5])) , 1L) && g_93[6].f1) , l_1987))) > g_731.f1) <= 0x2134D8CE9282BF33LL) , p_16) < 0x0E78BBC20A03A236LL), p_17)))) , g_1988)) != (void*)0), l_1951)) == (*g_648)) , p_17) && 7UL) > 0x0FL), l_1955)) && (*g_345)), (*g_648)))), (*g_1247))) >= g_1601.f1), (****l_1984))), 12)) , (-1L)), 0L)))))
        { /* block id: 1037 */
            const int32_t l_2047 = 0xAA25DE33L;
            (***g_893) |= 0L;
            if (p_16)
            { /* block id: 1039 */
                uint8_t l_1993 = 0x96L;
                l_1993++;
                return p_16;
            }
            else
            { /* block id: 1042 */
                int64_t **l_2020 = (void*)0;
                int32_t l_2042 = 6L;
                int8_t l_2049 = 0x2AL;
                union U0 *l_2058 = (void*)0;
                for (g_23 = 0; (g_23 <= 6); g_23 += 1)
                { /* block id: 1045 */
                    int8_t l_2017 = 0xBEL;
                    int32_t l_2019 = 0L;
                    l_2019 = (safe_unary_minus_func_uint8_t_u((safe_lshift_func_uint16_t_u_u((safe_div_func_int16_t_s_s(((((*g_648) == 0x9CB3BB30A7BE0145LL) == ((safe_sub_func_int32_t_s_s(p_16, (****g_1986))) != (safe_mul_func_int16_t_s_s(((safe_lshift_func_int8_t_s_u((safe_mul_func_int8_t_s_s((safe_mul_func_uint8_t_u_u(((((*g_1247) = 0x31L) , ((~(0x47L == (0x7EL || (safe_rshift_func_int8_t_s_s((*g_1247), (safe_div_func_uint32_t_u_u(l_2017, 0xD15113D1L))))))) || l_1955)) > p_16), g_69)), (-1L))), 1)) , 4L), g_289.f1)))) , l_1955), l_2018)), g_221))));
                }
                if ((&g_1247 != &g_1247))
                { /* block id: 1049 */
                    int8_t *l_2045 = &g_90.f1;
                    int8_t *l_2046 = &l_19[1][6][8];
                    const int32_t l_2048 = 0xA11E6AEAL;
                    uint32_t *l_2050 = &g_66[7][1];
                    int32_t l_2052 = 0x45B1E6C0L;
                    uint8_t *l_2077 = &g_1587;
                    l_2052 |= (!(l_2020 != ((((safe_add_func_int16_t_s_s((safe_sub_func_int32_t_s_s(((g_400 >= (((*l_2050) = (safe_lshift_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u(((((**g_647) &= l_2029) , (safe_div_func_int16_t_s_s(((0xD842FC582F78A697LL <= (safe_mul_func_int16_t_s_s(((((safe_mul_func_uint8_t_u_u(0x92L, ((safe_mod_func_int8_t_s_s(((((**g_647)++) >= ((safe_mod_func_int8_t_s_s(((p_16 <= l_2042) , 0xBDL), (safe_sub_func_int16_t_s_s(((((*l_2046) = (*g_1247)) > p_16) || p_17), l_2047)))) > l_2048)) | p_16), 0xE9L)) || p_17))) != l_2049) & 0x2AL) >= p_16), 0x320AL))) ^ (*g_1247)), 0x9329L))) > g_1386.f1), l_2049)) >= p_17), l_2047))) <= l_1951)) >= (-1L)), 0xD261A758L)), p_17)) || l_2048) < p_17) , l_2051)));
                    (*****g_1985) = (safe_div_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u((safe_unary_minus_func_int8_t_s(p_16)), ((l_2058 == (void*)0) , (((*l_2077) = (!(safe_add_func_uint32_t_u_u(g_340.f1, (safe_div_func_uint8_t_u_u(((safe_div_func_int8_t_s_s(0xD2L, 0xFEL)) ^ ((*l_1992) &= (safe_mod_func_int32_t_s_s(((0x6A2AL < (safe_mod_func_uint16_t_u_u((g_1355++), (safe_add_func_int8_t_s_s(((safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(p_16, (l_2049 > l_1951))), l_1955)) , (*g_1247)), 0x6FL))))) , 0x6E47682FL), 8L)))), l_2047)))))) != g_1635)))) <= l_2052), 0xBDL));
                }
                else
                { /* block id: 1059 */
                    for (g_312 = 0; (g_312 <= 2); g_312 += 1)
                    { /* block id: 1062 */
                        int i;
                        (*g_1447) = (**g_893);
                        if (p_17)
                            break;
                        l_22[g_312] = (&g_1381 == &l_2029);
                        (***g_1445) = (void*)0;
                    }
                }
            }
        }
        else
        { /* block id: 1070 */
            (*g_345) ^= ((****l_1984) |= p_16);
        }
        for (g_1923 = 0; (g_1923 <= 2); g_1923 += 1)
        { /* block id: 1076 */
            uint32_t l_2109 = 0x5E52B9DAL;
            int32_t l_2111 = (-1L);
            int32_t l_2132 = 0L;
            for (g_1587 = 0; (g_1587 <= 2); g_1587 += 1)
            { /* block id: 1079 */
                uint8_t l_2083 = 0UL;
                int16_t l_2088[5][9][1] = {{{(-1L)},{(-1L)},{(-6L)},{1L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{1L}},{{(-6L)},{(-1L)},{(-1L)},{(-6L)},{1L},{(-6L)},{(-1L)},{(-1L)},{(-6L)}},{{1L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{1L},{(-6L)},{(-1L)},{(-1L)}},{{(-6L)},{1L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{1L},{(-6L)},{(-1L)}},{{(-1L)},{(-6L)},{1L},{(-6L)},{(-1L)},{(-1L)},{(-6L)},{1L},{(-6L)}}};
                int16_t * const ****l_2118 = &g_2114;
                int32_t l_2126[9] = {1L,1L,1L,1L,1L,1L,1L,1L,1L};
                int8_t l_2141 = (-1L);
                int i, j, k;
                for (g_127 = 0; (g_127 <= 2); g_127 += 1)
                { /* block id: 1082 */
                    int32_t l_2078 = 0xF69ACE3DL;
                    int32_t l_2095 = 3L;
                    union U0 *l_2112 = &g_2113[1];
                    int i;
                    if (((l_2078 = p_17) <= ((safe_add_func_uint64_t_u_u((safe_mod_func_uint8_t_u_u((g_423 ^= 0xB6L), (*g_1247))), 18446744073709551615UL)) && ((*g_1247) ^= (~(((l_2083 ^ l_1951) , (((((safe_div_func_uint16_t_u_u((~(safe_lshift_func_int16_t_s_s(l_2088[1][8][0], ((safe_rshift_func_int16_t_s_u((((g_1048 , (safe_add_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((0xE64FE4B0L == p_16), p_17)), 0x10C8L))) ^ p_17) <= p_16), 1)) && 0xC34BL)))), p_16)) , l_2095) != l_1955) < 0x5EL) || 4294967287UL)) , (-2L)))))))
                    { /* block id: 1086 */
                        uint32_t *l_2101 = (void*)0;
                        int32_t l_2106 = 0x40734D93L;
                        int64_t *l_2108[3];
                        uint16_t *l_2110 = &g_366;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_2108[i] = &g_67;
                        l_22[g_1587] &= (safe_div_func_int8_t_s_s((((((!((safe_lshift_func_uint16_t_u_s(((l_1951 != (g_2100 || ((p_16 != ((void*)0 == l_2101)) == ((*l_1992) = (safe_lshift_func_int8_t_s_u((((*l_2110) = (safe_add_func_uint8_t_u_u(l_2106, (((l_2109 = ((((**g_1986) = (**g_1986)) != (**g_1445)) & (safe_unary_minus_func_int32_t_s(l_2018)))) , 18446744073709551615UL) <= (**g_647))))) != p_17), g_1926)))))) && (**g_647)), l_2111)) , 0x89L)) < l_2111) | (*g_1247)) >= 0x36E6L) & l_2029), 1L));
                    }
                    else
                    { /* block id: 1092 */
                        int i;
                        l_2112 = (**g_1055);
                        if ((*g_13))
                            break;
                        (**g_1446) = (void*)0;
                    }
                }
                (*g_1447) = &p_16;
                if (p_16)
                    continue;
                if ((((((*l_2118) = g_2114) != l_2119) == ((safe_add_func_int32_t_s_s(((safe_add_func_int32_t_s_s(((!18446744073709551611UL) , ((l_2132 ^= (((((void*)0 == l_2118) || ((1L > ((safe_add_func_int16_t_s_s(((**g_2116) & ((l_2126[8] = l_2109) || ((safe_mod_func_int32_t_s_s((safe_div_func_uint32_t_u_u(((void*)0 == &p_17), 0xCDFFF3BFL)), l_2109)) , l_2131[2]))), p_16)) != (**g_647))) , l_2111)) <= (***g_2115)) & 0xAA9BF00DL)) != (-5L))), g_1592[0][4][1].f2)) || 8UL), g_1322.f1)) < 0x5C656C85AFB17B71LL)) , (****g_1986)))
                { /* block id: 1103 */
                    (**g_1446) = (void*)0;
                    if (p_16)
                        continue;
                }
                else
                { /* block id: 1106 */
                    uint8_t l_2142 = 0x51L;
                    uint64_t *l_2155 = &g_315[1][3][2];
                    uint8_t *l_2156 = &l_2083;
                    uint32_t l_2157 = 0xD74F4552L;
                    int i, j;
                    l_22[g_1923] = (((((safe_sub_func_int64_t_s_s((l_2132 = ((g_66[g_1587][g_1923] &= (p_17 ^ ((l_2088[1][8][0] , (((safe_rshift_func_int8_t_s_s(p_17, (safe_div_func_int16_t_s_s((****g_2114), p_16)))) != l_2132) < (4294967292UL && ((l_2111 > (l_2142 = (((((safe_add_func_uint32_t_u_u(g_615, 6UL)) != (****g_1986)) < l_2141) > l_2029) || p_17))) != p_17)))) ^ l_2088[3][3][0]))) >= p_17)), 0x0663FF9855AF6714LL)) && 0x32010904L) , 0x0032B82A2A7419BDLL) & (*g_648)) && g_145);
                    if ((safe_lshift_func_uint8_t_u_u(g_546[5][4], ((((safe_mod_func_uint32_t_u_u((((*l_2156) = (((*l_2155) |= (safe_lshift_func_int16_t_s_u(((!8UL) < ((p_17 || p_16) & ((safe_mul_func_uint16_t_u_u((safe_add_func_uint8_t_u_u(((*l_1992) ^= (safe_sub_func_uint16_t_u_u(l_1955, (**g_2116)))), (((+(***g_2115)) ^ p_16) == (*g_648)))), p_16)) && (*g_1448)))), 7))) == 0x4ED20875007E376ELL)) & l_2088[4][6][0]), p_17)) >= (*g_13)) | p_16) | l_2157))))
                    { /* block id: 1114 */
                        uint32_t *l_2159 = (void*)0;
                        uint32_t **l_2158[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_2158[i] = &l_2159;
                        g_2160 = l_2158[0];
                    }
                    else
                    { /* block id: 1116 */
                        if (g_731.f1)
                            goto lbl_2162;
                        if ((*****g_1985))
                            break;
                        l_2163 &= ((****g_1986) = (*g_345));
                        if (l_2126[0])
                            continue;
                    }
                }
            }
        }
    }
    l_2164 = &p_16;
    return p_16;
}


/* ------------------------------------------ */
/* 
 * reads : g_21 g_28 g_62 g_23 g_13 g_14 g_66 g_102 g_93.f1 g_90.f1 g_138 g_90.f2 g_149 g_104 g_169 g_145 g_69 g_131 g_147 g_198 g_222 g_221 g_127 g_287 g_295 g_289.f1 g_67 g_289.f2 g_288 g_315 g_345 g_312 g_366 g_363 g_423 g_470 g_93.f2 g_402 g_340.f2 g_459 g_597 g_615 g_625 g_648 g_893 g_546 g_894 g_1371 g_1386.f1 g_1414 g_1048 g_1247
 * writes: g_62 g_66 g_67 g_69 g_21 g_102 g_104 g_90.f2 g_149 g_169 g_145 g_93.f1 g_147 g_198 g_222 g_127 g_287 g_289.f1 g_295 g_312 g_315 g_289.f2 g_288 g_340.f1 g_345 g_366 g_363 g_423 g_221 g_131 g_470 g_340.f2 g_459 g_647 g_1386.f1 g_90.f1 g_1048
 */
static int32_t * func_29(int32_t ** p_30)
{ /* block id: 15 */
    int32_t l_36 = 1L;
    int32_t l_47 = 0x1C91930EL;
    int32_t l_464 = 0xA3294434L;
    int32_t l_465 = (-1L);
    int32_t l_466 = 0x5253D42AL;
    int32_t l_467 = 0xB7D92049L;
    int32_t l_468 = 0L;
    uint16_t *l_552 = &g_222;
    const int32_t *l_556 = &l_467;
    const uint8_t *l_589 = &g_102;
    uint16_t l_600 = 1UL;
    uint64_t *l_626 = &g_315[0][6][4];
    uint32_t *l_627 = &g_69;
    int32_t l_635 = 0x7F12CDA7L;
    int64_t *l_636 = &g_459;
    int8_t l_637 = 0x03L;
    int64_t l_673 = 0x23314E759213B34CLL;
    int64_t l_683 = 6L;
    uint8_t *l_689 = &g_102;
    int16_t l_834[8][3] = {{1L,0x815FL,(-9L)},{1L,1L,0x815FL},{0x4C03L,0x815FL,0x815FL},{0x815FL,(-10L),(-9L)},{0x4C03L,(-10L),0x4C03L},{1L,0x815FL,(-9L)},{1L,1L,0x815FL},{0x4C03L,0x815FL,0x815FL}};
    uint64_t l_895 = 0xAF2C0FCF9812FAB2LL;
    int64_t l_971[6][10][4] = {{{1L,(-1L),0xE9C6B40DFB67AEE8LL,0x448059CBEF645ED8LL},{0xBE8EA19014A39832LL,0xF15CA4E80DB125CELL,0x70DA6250021A163DLL,(-1L)},{7L,0x1EF6D3ABB86C3021LL,0x1EF6D3ABB86C3021LL,7L},{0x559669957473C8D5LL,0x412638D22B764143LL,0xFF4E3C683A31489ELL,0xE967D6340EA0FBCFLL},{0xA06332DB603DBA5ELL,0x276DE7151FACFC27LL,1L,0x016D88C455718724LL},{0xDC4655FAF1D57F79LL,5L,0x412638D22B764143LL,0x016D88C455718724LL},{0xD30B69B10AD6DD20LL,(-4L),(-7L),(-7L)},{0x63F223F059A23047LL,(-1L),0x1EF6D3ABB86C3021LL,0x25583AF8AE9DE084LL},{0x86F0188CFDCEEF36LL,1L,(-1L),1L},{(-1L),0L,(-4L),0x59E012952333FC12LL}},{{0x3090CDCCD6EF3C88LL,0xD30B69B10AD6DD20LL,0x016D88C455718724LL,(-6L)},{0x6EB75884B3314BAELL,(-10L),9L,(-4L)},{0L,0x59E012952333FC12LL,0xDD87DA8F5D500D0ALL,6L},{0x665DFFB583CFD48FLL,0L,(-4L),1L},{1L,(-1L),1L,0L},{0x18D4B9BB2E29A5EFLL,(-5L),1L,(-10L)},{0L,(-4L),0xD30B69B10AD6DD20LL,0x1EF6D3ABB86C3021LL},{(-6L),1L,(-5L),0xF699B5265CC11B49LL},{7L,0x9FF1F9E7BB8480AFLL,(-1L),0x4EF73A87905B026ALL},{(-6L),0xFC7FB33974C129CBLL,0x276DE7151FACFC27LL,0x665DFFB583CFD48FLL}},{{(-10L),(-1L),0xA44C92DDD1717940LL,0x8119E481B5A1D957LL},{0L,0x276DE7151FACFC27LL,(-6L),(-2L)},{0xC7BFFAFBE527B2BDLL,0xDA49BE2E0D1C2E1FLL,0xFC7FB33974C129CBLL,0L},{0xF699B5265CC11B49LL,0L,4L,0x925A7368E9E4422DLL},{0x5CCBBE8FCBABA692LL,0x9EED8D8DD49A3897LL,0x8119E481B5A1D957LL,(-5L)},{0xDD87DA8F5D500D0ALL,1L,1L,0L},{0x90F6726E0F2DBF79LL,0x016D88C455718724LL,1L,0x63F223F059A23047LL},{0L,0x82E9CEDBDA5EB26BLL,0x665DFFB583CFD48FLL,(-6L)},{0x559669957473C8D5LL,1L,0x559669957473C8D5LL,0x9FF1F9E7BB8480AFLL},{0x910B494478CD9F23LL,0x01815E51ABA7F3C4LL,0xAAF98596F8FB492BLL,1L}},{{(-1L),0x9FF0EE188CEA0794LL,0x4DC17F9CDBB1812BLL,0x01815E51ABA7F3C4LL},{(-4L),0x1EF6D3ABB86C3021LL,0x4DC17F9CDBB1812BLL,0xD9C9085ABD95C9DDLL},{(-1L),(-6L),0xAAF98596F8FB492BLL,0L},{0x910B494478CD9F23LL,0x8119E481B5A1D957LL,0x559669957473C8D5LL,1L},{0x559669957473C8D5LL,1L,0x665DFFB583CFD48FLL,0xA06332DB603DBA5ELL},{0L,0xDC4655FAF1D57F79LL,1L,0x86F0188CFDCEEF36LL},{0x90F6726E0F2DBF79LL,0L,1L,0x86C3349176872C59LL},{0xDD87DA8F5D500D0ALL,0xD8B9992A17F7195ALL,0x8119E481B5A1D957LL,1L},{0x5CCBBE8FCBABA692LL,(-6L),4L,(-4L)},{0xF699B5265CC11B49LL,0xAAF98596F8FB492BLL,0xFC7FB33974C129CBLL,0xAE219D6C69412326LL}},{{0xC7BFFAFBE527B2BDLL,9L,(-6L),0x412638D22B764143LL},{0L,(-1L),0xA44C92DDD1717940LL,0x910B494478CD9F23LL},{(-10L),1L,0x276DE7151FACFC27LL,0xE7AAA15CB2CEA5ECLL},{(-6L),0xFF4E3C683A31489ELL,(-1L),0x52A8044857A93CC1LL},{7L,0x63F223F059A23047LL,(-5L),0x98BC44A8413158CBLL},{(-6L),1L,0xD30B69B10AD6DD20LL,0x4DC17F9CDBB1812BLL},{0L,0x665DFFB583CFD48FLL,1L,5L},{0x18D4B9BB2E29A5EFLL,0x70DA6250021A163DLL,1L,7L},{1L,0x448059CBEF645ED8LL,(-4L),0x5CCBBE8FCBABA692LL},{0x665DFFB583CFD48FLL,0xF699B5265CC11B49LL,0xDD87DA8F5D500D0ALL,0x9EED8D8DD49A3897LL}},{{0L,0x18D4B9BB2E29A5EFLL,9L,(-1L)},{0x6EB75884B3314BAELL,0x3DA507BCBEFC248DLL,0x016D88C455718724LL,0xA44C92DDD1717940LL},{0x3090CDCCD6EF3C88LL,(-10L),0x910B494478CD9F23LL,0xE9C6B40DFB67AEE8LL},{1L,9L,0x9FF1F9E7BB8480AFLL,0x9FF1F9E7BB8480AFLL},{0xAE219D6C69412326LL,0xAE219D6C69412326LL,1L,0x01815E51ABA7F3C4LL},{1L,0xF699B5265CC11B49LL,0x5FA084572BB09CA2LL,0x1EF6D3ABB86C3021LL},{0x63F223F059A23047LL,0xE967D6340EA0FBCFLL,(-1L),0x5FA084572BB09CA2LL},{0x559669957473C8D5LL,0xE967D6340EA0FBCFLL,0x3DA507BCBEFC248DLL,0x1EF6D3ABB86C3021LL},{0xE967D6340EA0FBCFLL,0xF699B5265CC11B49LL,0x9FF0EE188CEA0794LL,0x01815E51ABA7F3C4LL},{0x86F0188CFDCEEF36LL,0xAE219D6C69412326LL,0x8119E481B5A1D957LL,0x9FF1F9E7BB8480AFLL}}};
    uint8_t l_1001 = 255UL;
    int32_t ***l_1093[8][6] = {{&g_894,&g_894,(void*)0,&g_894,&g_894,&g_894},{&g_894,&g_894,&g_894,&g_894,&g_894,&g_894},{&g_894,&g_894,&g_894,&g_894,(void*)0,&g_894},{&g_894,&g_894,&g_894,&g_894,&g_894,&g_894},{&g_894,&g_894,&g_894,&g_894,(void*)0,&g_894},{&g_894,&g_894,&g_894,&g_894,&g_894,&g_894},{&g_894,&g_894,&g_894,&g_894,&g_894,&g_894},{&g_894,&g_894,&g_894,&g_894,&g_894,&g_894}};
    const int16_t **l_1130 = (void*)0;
    const int16_t ***l_1129 = &l_1130;
    int32_t l_1145[10] = {0x8B97BE7AL,0xB1653123L,0x8B97BE7AL,0xB1653123L,0x8B97BE7AL,0xB1653123L,0x8B97BE7AL,0xB1653123L,0x8B97BE7AL,0xB1653123L};
    int32_t **** const l_1152 = &l_1093[4][1];
    uint32_t l_1224 = 1UL;
    int32_t l_1250 = 0xBE75E4DEL;
    int32_t l_1251 = (-1L);
    int32_t l_1380 = 3L;
    union U0 *l_1385[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    int64_t l_1389 = 0x9B6412F7D8489259LL;
    int8_t l_1390 = (-1L);
    int64_t **l_1392 = &l_636;
    int64_t ***l_1391 = &l_1392;
    uint16_t l_1393[9] = {0x9B6FL,0x9B6FL,1UL,0x9B6FL,0x9B6FL,1UL,0x9B6FL,0x9B6FL,1UL};
    int32_t l_1421 = 0L;
    union U0 ****l_1422 = &g_1055;
    uint64_t l_1567 = 0x4377E4F8DAC037ADLL;
    int16_t l_1594 = (-5L);
    uint64_t l_1642 = 0x1F8046BF128D8D48LL;
    uint8_t l_1723 = 7UL;
    int16_t l_1728 = 0x209BL;
    uint32_t l_1764[8][4] = {{18446744073709551609UL,0UL,0x39AAFEE8L,0UL},{0UL,18446744073709551614UL,0x39AAFEE8L,0x39AAFEE8L},{18446744073709551609UL,18446744073709551609UL,0UL,0x39AAFEE8L},{0UL,18446744073709551614UL,0UL,0UL},{0UL,0UL,0UL,0UL},{18446744073709551609UL,0UL,0x39AAFEE8L,0UL},{0UL,18446744073709551614UL,0x39AAFEE8L,0x39AAFEE8L},{18446744073709551609UL,18446744073709551609UL,0UL,0x39AAFEE8L}};
    uint8_t l_1766 = 247UL;
    uint32_t l_1798 = 2UL;
    int i, j, k;
    if ((((safe_mul_func_uint16_t_u_u(((safe_sub_func_uint64_t_u_u(l_36, ((void*)0 == &g_21))) >= l_36), (((**p_30) && (**p_30)) , func_37(((func_42((l_36 , ((l_47 |= ((safe_div_func_uint32_t_u_u(g_21, ((l_36 >= l_36) | 0L))) != (-1L))) | g_28)), (*p_30)) , l_36) , g_363), &l_36, g_221, l_36)))) == (*g_13)) || (-10L)))
    { /* block id: 243 */
        int32_t *l_463[4];
        int16_t l_469 = (-9L);
        uint64_t *l_473[9][4][7] = {{{&g_312,&g_315[1][3][2],&g_312,(void*)0,&g_312,(void*)0,&g_312},{(void*)0,(void*)0,&g_315[1][2][6],&g_315[1][3][1],&g_312,&g_315[1][3][2],(void*)0},{(void*)0,&g_312,(void*)0,&g_315[1][3][2],&g_315[1][3][2],(void*)0,(void*)0},{&g_315[1][3][2],(void*)0,&g_315[1][1][1],(void*)0,&g_315[1][3][2],&g_312,&g_315[1][7][0]}},{{&g_315[0][2][8],&g_315[0][0][2],&g_312,&g_312,(void*)0,&g_315[0][2][2],(void*)0},{&g_312,(void*)0,&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],(void*)0,&g_312},{&g_312,(void*)0,&g_315[1][3][2],&g_315[0][0][2],&g_315[1][3][2],&g_315[1][3][2],&g_312},{&g_315[0][2][8],&g_312,&g_315[1][5][3],(void*)0,&g_315[1][3][2],(void*)0,&g_315[1][3][2]}},{{&g_315[1][3][2],&g_312,&g_315[0][2][2],&g_312,(void*)0,&g_315[1][1][4],(void*)0},{&g_312,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&g_315[1][3][2]},{&g_315[1][3][2],(void*)0,(void*)0,&g_315[1][2][3],&g_315[1][3][1],(void*)0,&g_315[1][3][1]},{&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],&g_312}},{{&g_312,&g_315[1][6][7],&g_315[1][3][2],(void*)0,(void*)0,&g_312,&g_315[0][6][7]},{(void*)0,&g_315[1][0][6],&g_315[0][6][7],(void*)0,(void*)0,&g_315[1][3][2],&g_312},{&g_315[1][1][1],&g_312,(void*)0,&g_315[1][4][2],&g_315[0][3][8],&g_315[1][3][2],&g_315[1][3][1]},{(void*)0,(void*)0,&g_312,&g_315[0][1][6],&g_312,(void*)0,&g_315[1][3][2]}},{{(void*)0,&g_315[1][3][2],&g_315[1][3][2],&g_315[1][2][6],(void*)0,&g_315[1][3][2],(void*)0},{&g_315[0][3][4],&g_315[0][0][2],(void*)0,&g_315[1][6][2],&g_315[1][3][2],&g_312,(void*)0},{&g_315[1][3][2],(void*)0,&g_315[1][6][7],&g_312,&g_315[0][5][4],&g_315[1][3][2],&g_315[1][3][2]},{&g_315[1][1][8],&g_312,&g_312,&g_315[1][3][2],&g_315[1][1][4],&g_315[1][3][2],(void*)0}},{{&g_315[1][5][7],&g_315[1][3][2],(void*)0,&g_315[0][0][2],&g_315[1][0][6],&g_315[1][3][2],&g_315[0][7][3]},{&g_312,&g_315[1][5][2],&g_312,&g_315[1][1][1],&g_315[0][3][6],&g_315[1][3][2],&g_315[1][3][2]},{(void*)0,&g_312,&g_315[1][3][2],&g_312,(void*)0,&g_312,&g_312},{&g_315[0][0][2],&g_315[1][3][2],&g_315[0][3][4],&g_315[1][3][2],&g_312,&g_315[1][3][2],&g_312}},{{(void*)0,&g_315[1][3][2],&g_315[1][3][2],&g_315[0][2][2],&g_315[1][3][2],(void*)0,&g_315[1][3][2]},{&g_315[1][3][2],(void*)0,(void*)0,&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],(void*)0},{(void*)0,(void*)0,&g_315[1][3][2],&g_315[1][3][2],(void*)0,&g_315[1][3][2],(void*)0},{&g_312,&g_315[1][3][2],&g_315[0][5][4],(void*)0,&g_315[0][2][8],&g_312,&g_315[1][4][1]}},{{&g_312,&g_312,(void*)0,&g_315[1][3][2],(void*)0,&g_315[1][3][2],(void*)0},{(void*)0,&g_315[1][1][4],(void*)0,&g_315[1][3][2],&g_315[1][3][2],(void*)0,&g_312},{&g_315[1][5][3],&g_312,&g_315[0][2][8],&g_315[1][4][1],&g_315[1][3][2],(void*)0,&g_315[0][1][7]},{&g_312,&g_315[1][5][7],&g_312,&g_315[1][3][2],&g_312,&g_315[1][1][4],&g_312}},{{&g_315[0][3][8],&g_315[1][3][2],&g_312,&g_315[1][3][2],(void*)0,&g_315[1][3][2],&g_315[1][5][3]},{&g_315[1][3][2],(void*)0,&g_315[0][7][3],&g_312,&g_315[0][3][6],&g_315[0][3][4],&g_315[1][3][2]},{&g_315[1][7][0],&g_315[1][3][2],&g_315[1][3][2],&g_315[1][3][2],&g_315[1][0][6],&g_312,(void*)0},{&g_312,&g_315[1][2][3],&g_315[1][2][6],&g_315[1][3][2],(void*)0,&g_315[1][3][2],&g_315[1][3][2]}}};
        uint64_t **l_474 = &l_473[8][1][2];
        int i, j, k;
        for (i = 0; i < 4; i++)
            l_463[i] = &l_36;
        --g_470;
        if ((((*l_474) = l_473[8][1][2]) == (void*)0))
        { /* block id: 246 */
            int32_t *l_475 = &l_464;
            (*p_30) = l_475;
            (*p_30) = &l_464;
            (*p_30) = &g_14;
        }
        else
        { /* block id: 250 */
            uint16_t l_484 = 0x035AL;
            int32_t *l_485[10][10] = {{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47},{&g_221,&l_47,(void*)0,(void*)0,&l_47,&g_221,&l_47,(void*)0,(void*)0,&l_47}};
            int i, j;
            for (g_145 = 0; (g_145 != (-15)); g_145--)
            { /* block id: 253 */
                for (g_289.f2 = 0; (g_289.f2 > (-22)); g_289.f2 = safe_sub_func_uint8_t_u_u(g_289.f2, 4))
                { /* block id: 256 */
                    int32_t *l_486 = &l_36;
                    for (g_222 = 2; (g_222 == 40); g_222++)
                    { /* block id: 259 */
                        (**p_30) &= (safe_rshift_func_int8_t_s_s(l_484, g_104[1][9]));
                    }
                    (*p_30) = l_485[6][3];
                    return &g_14;
                }
            }
        }
        g_131 = 8L;
        g_131 &= l_465;
    }
    else
    { /* block id: 269 */
        const int32_t l_525 = 0L;
        int32_t *l_529 = &l_468;
        for (g_366 = 0; (g_366 <= 6); g_366 += 1)
        { /* block id: 272 */
            int32_t l_491 = 1L;
            int8_t *l_500 = &g_340.f2;
            int8_t *l_501 = &g_147;
            uint32_t *l_502 = (void*)0;
            uint32_t *l_503 = &g_62[2][7];
            int16_t l_506 = 0xA6B1L;
            const int32_t *l_528[4][3] = {{&l_466,&l_466,&l_466},{&l_465,(void*)0,&l_465},{&l_466,&l_466,&l_466},{&l_465,(void*)0,&l_465}};
            int32_t l_532[6] = {3L,3L,3L,3L,3L,3L};
            int32_t *l_533[1][1][1];
            const uint64_t *l_586 = &g_402;
            uint16_t l_614[10][5] = {{0x1685L,65531UL,65531UL,0x1685L,0x1685L},{0x681CL,4UL,0x681CL,4UL,0x681CL},{0x1685L,0x1685L,65531UL,65531UL,0x1685L},{0xE27BL,4UL,0xE27BL,4UL,0xE27BL},{0x1685L,65531UL,65531UL,0x1685L,0x1685L},{0x681CL,4UL,0x681CL,4UL,0x681CL},{0x1685L,0x1685L,65531UL,65531UL,0x1685L},{0xE27BL,4UL,0xE27BL,4UL,0xE27BL},{0x1685L,65531UL,65531UL,0x1685L,0x1685L},{0x681CL,4UL,0x681CL,4UL,0x681CL}};
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_533[i][j][k] = &g_221;
                }
            }
            (**p_30) = (((g_93[6].f2 >= (safe_add_func_int32_t_s_s(((safe_rshift_func_int16_t_s_s((g_402 & l_491), ((safe_mul_func_int16_t_s_s(l_466, (safe_add_func_int8_t_s_s((safe_sub_func_uint16_t_u_u((safe_div_func_int32_t_s_s((0xAADD4B255D955E4CLL & ((((*l_501) = ((*l_500) &= 0x1DL)) > (((*l_503)++) <= (g_104[1][9] , (((l_491 > g_66[3][1]) < g_221) <= l_465)))) ^ 0xD1L)), g_93[6].f1)), l_465)), g_90.f1)))) | 0xAE3616FCAE206AE2LL))) | 0x77L), l_491))) , l_465) == l_506);
            (**p_30) = (safe_unary_minus_func_int8_t_s(0L));
            for (g_69 = 1; (g_69 <= 6); g_69 += 1)
            { /* block id: 280 */
                int8_t l_524 = 0x28L;
                const int32_t *l_527 = &g_28;
                const int32_t **l_526[6][2] = {{&l_527,&l_527},{&l_527,&l_527},{&l_527,&l_527},{&l_527,&l_527},{&l_527,&l_527},{&l_527,&l_527}};
                int i, j;
            }
            for (g_69 = 0; (g_69 <= 1); g_69 += 1)
            { /* block id: 297 */
                uint8_t l_531 = 0x00L;
                union U0 **l_539 = &g_288;
                const int32_t **l_555[10] = {&l_528[2][0],&l_528[3][0],&l_528[2][0],&l_528[2][0],&l_528[3][0],&l_528[2][0],&l_528[2][0],&l_528[2][0],&l_528[1][2],&l_528[1][2]};
                int32_t l_577 = 1L;
                uint64_t **l_595 = (void*)0;
                uint16_t l_616[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_616[i] = 0x37C3L;
                (*p_30) = ((l_532[5] = ((*l_529) = l_531)) , (*p_30));
                for (l_465 = 0; (l_465 <= 1); l_465 += 1)
                { /* block id: 303 */
                    const int8_t *l_545[6] = {&g_546[0][5],&g_546[0][5],&g_546[0][5],&g_546[0][5],&g_546[0][5],&g_546[0][5]};
                    const int8_t **l_544 = &l_545[2];
                    int32_t l_551 = 1L;
                    int i;
                    for (l_468 = 0; (l_468 <= 6); l_468 += 1)
                    { /* block id: 306 */
                        union U0 ***l_538 = &g_287;
                        const int8_t *l_543[1][1];
                        const int8_t **l_542[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 1; j++)
                                l_543[i][j] = &g_289.f1;
                        }
                        (*p_30) = l_533[0][0][0];
                        (**p_30) = (~(((safe_div_func_int8_t_s_s(((&g_138 == ((safe_div_func_uint32_t_u_u(0x30AFA6C8L, (g_315[g_69][(g_69 + 5)][(g_69 + 1)] , g_315[l_465][(l_465 + 6)][(g_366 + 1)]))) , ((*l_538) = &g_288))) <= g_62[(g_69 + 4)][(g_69 + 4)]), (g_66[(g_366 + 3)][g_366] & g_340.f2))) , &g_288) == l_539));
                        (**p_30) = (safe_mul_func_int16_t_s_s(((((*l_500) = ((l_544 = l_542[2]) != (void*)0)) != (*l_529)) <= ((safe_mul_func_int8_t_s_s((safe_rshift_func_uint8_t_u_u(l_551, l_551)), (l_552 != &g_169))) >= (*l_529))), (safe_div_func_int8_t_s_s((l_531 < l_531), l_551))));
                    }
                }
                l_556 = &g_28;
                for (g_289.f2 = 4; (g_289.f2 >= 0); g_289.f2 -= 1)
                { /* block id: 318 */
                    int32_t l_569 = (-1L);
                    int32_t l_574 = 0x9AD6C5EDL;
                    int32_t l_576 = 0L;
                    const int32_t ***l_613 = &l_555[2];
                    for (g_459 = 0; (g_459 <= 1); g_459 += 1)
                    { /* block id: 321 */
                        uint16_t *l_572 = (void*)0;
                        uint16_t *l_573[4] = {&g_169,&g_169,&g_169,&g_169};
                        int32_t l_575[3];
                        uint8_t *l_594 = (void*)0;
                        uint64_t ***l_596 = &l_595;
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                            l_575[i] = 0xB25C5ECBL;
                        l_569 = ((+0L) && ((g_315[g_459][(g_69 + 3)][(g_459 + 4)] && (safe_mul_func_int8_t_s_s((safe_mul_func_int8_t_s_s((safe_sub_func_uint16_t_u_u(g_315[g_459][(g_69 + 3)][(g_459 + 4)], ((safe_mul_func_uint16_t_u_u(((*l_552) = (safe_rshift_func_int16_t_s_u((safe_sub_func_int16_t_s_s(g_222, (*l_529))), 1))), l_569)) , (-7L)))), (safe_add_func_int64_t_s_s((4UL ^ (g_149--)), (((safe_add_func_uint64_t_u_u((safe_rshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s((((&g_400 != l_586) || 0x1AL) == g_312), 0x3C6DL)), (*l_529))), (*l_556))) >= (**p_30)) , g_315[g_459][(g_69 + 3)][(g_459 + 4)]))))), 0xC9L))) > 4294967287UL));
                        (**p_30) |= (((((g_23 , (++g_66[g_366][(g_289.f2 + 1)])) , l_589) != (void*)0) | ((safe_rshift_func_uint16_t_u_u(l_575[2], 9)) && ((g_312 == ((1UL ^ (l_577 = ((*l_556) >= g_340.f2))) || (((*l_596) = l_595) == g_597))) <= 0UL))) && l_600);
                    }
                    (*l_529) = ((((4UL < (safe_lshift_func_int8_t_s_s(0xACL, (((safe_mul_func_uint16_t_u_u((((*l_529) <= (safe_add_func_uint16_t_u_u((safe_lshift_func_int16_t_s_s(((safe_div_func_uint64_t_u_u((g_23 != g_69), ((((safe_sub_func_uint32_t_u_u(((((0x19L & (18446744073709551608UL > ((((*l_613) = &l_528[3][0]) == &g_345) || (*l_556)))) , l_569) , l_614[2][1]) , 0UL), 0UL)) , (-1L)) <= g_169) , 0x15BFE9B3ADBFB178LL))) , 0x7186L), g_289.f2)), l_531))) | l_577), 1UL)) > g_615) && 0xC2L)))) , g_90.f2) <= g_169) < 0UL);
                    if ((**p_30))
                        break;
                    for (g_102 = 0; (g_102 <= 9); g_102 += 1)
                    { /* block id: 335 */
                        int i, j;
                        (**l_613) = l_528[(g_69 + 2)][g_69];
                        --l_616[0];
                    }
                }
            }
        }
        return &g_363;
    }
    if ((safe_mod_func_uint16_t_u_u((--(*l_552)), (safe_add_func_int32_t_s_s(((((*l_626) = g_625) == ((((*l_627)--) , (((*l_636) = (((safe_div_func_uint8_t_u_u(((((safe_rshift_func_uint8_t_u_s(((*l_556) ^ 1UL), ((*l_556) == (safe_unary_minus_func_uint8_t_u(((*g_13) && (&g_198 != &g_470))))))) , 65535UL) == ((*l_556) && (*l_556))) , (*l_556)), (*l_556))) , l_635) || (*l_556))) > (*l_556))) > 0x6E7AL)) <= (*l_556)), l_637)))))
    { /* block id: 348 */
        int16_t l_642 = (-8L);
        uint64_t **l_645 = &l_626;
        uint16_t *l_672 = (void*)0;
        const uint64_t l_724 = 0x27F52E2FDFCECD8DLL;
        int32_t **l_749 = &g_345;
        int32_t * const * const l_827 = (void*)0;
        int32_t * const * const *l_826 = &l_827;
        union U0 *l_928 = (void*)0;
        for (l_468 = 14; (l_468 < (-22)); --l_468)
        { /* block id: 351 */
            uint32_t l_653 = 18446744073709551609UL;
            uint8_t l_698[4][3][3] = {{{0x43L,0x55L,0x45L},{0xAAL,253UL,1UL},{0xAAL,0xAAL,0x49L}},{{0x43L,253UL,0x49L},{253UL,0x55L,1UL},{0x43L,0x55L,0x45L}},{{0xAAL,253UL,1UL},{0xAAL,0xAAL,0x49L},{0x43L,253UL,0x49L}},{{253UL,0x55L,1UL},{0x43L,0x55L,0x45L},{0xAAL,253UL,1UL}}};
            uint64_t l_712[9] = {0xEB738CBE71A9525CLL,0xEB738CBE71A9525CLL,0UL,0xEB738CBE71A9525CLL,0xEB738CBE71A9525CLL,0UL,0xEB738CBE71A9525CLL,0xEB738CBE71A9525CLL,0UL};
            int32_t l_771 = 0x47E2C2C1L;
            int32_t l_836[1][1];
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 1; j++)
                    l_836[i][j] = 0xA5FE9C54L;
            }
        }
        (*p_30) = (*p_30);
        if ((*g_13))
        { /* block id: 454 */
            uint64_t **l_837 = (void*)0;
            uint64_t ***l_838[5] = {&l_645,&l_645,&l_645,&l_645,&l_645};
            int32_t l_839 = 1L;
            int32_t l_888 = 0x3F5CD709L;
            int32_t l_932 = 0x2FE0A090L;
            int i;
            g_647 = l_837;
            if ((l_839 || ((+(1UL && 0x4950D6D3L)) , ((-9L) < (safe_unary_minus_func_int8_t_s(l_839))))))
            { /* block id: 456 */
                int16_t l_847 = 0x09AEL;
                for (g_312 = 0; (g_312 <= 1); g_312 += 1)
                { /* block id: 459 */
                    uint64_t l_841[6] = {1UL,1UL,1UL,1UL,1UL,1UL};
                    int32_t l_854 = 0x68D558BEL;
                    int16_t *l_857 = &l_834[5][1];
                    uint64_t **l_869 = (void*)0;
                    int i;
                    for (l_839 = 0; l_839 < 5; l_839 += 1)
                    {
                        l_838[l_839] = &g_647;
                    }
                    (*p_30) = (*p_30);
                    if ((l_841[5] > ((-5L) && (((safe_unary_minus_func_uint8_t_u((safe_add_func_int64_t_s_s(((*l_645) != (((*l_857) = ((((l_847 & (((safe_div_func_uint8_t_u_u(0x8DL, ((safe_rshift_func_int8_t_s_s((0x14EC419B02CBE2ACLL > l_839), 1)) && (--(*l_626))))) == ((l_854 == ((((l_841[5] != (*l_556)) & 0L) ^ 6UL) | l_839)) > (*l_556))) == g_366)) , l_847) >= l_839) != 247UL)) , (void*)0)), 0x9FB674DAF058D100LL)))) , 1L) >= (*l_556)))))
                    { /* block id: 464 */
                        int16_t * const *l_863 = &l_857;
                        int16_t * const **l_862 = &l_863;
                        int32_t l_864 = 0L;
                        int8_t *l_867 = &g_340.f2;
                        int32_t *l_868 = &l_635;
                        (*l_868) = (+(safe_add_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(g_423, ((*l_689) = (((void*)0 != l_862) || (+(g_90.f2 = ((*l_867) |= ((l_864 = ((*g_287) == (void*)0)) , (g_289.f2 <= (safe_rshift_func_int16_t_s_s((l_672 != &l_600), 15))))))))))), l_839)));
                        (*l_868) = (l_869 == &g_648);
                    }
                    else
                    { /* block id: 471 */
                        uint32_t l_881 = 0x8A50203AL;
                        int64_t l_891 = 1L;
                        int32_t *l_896 = (void*)0;
                        int32_t *l_897[9][2][10] = {{{&g_21,&l_47,(void*)0,&g_14,(void*)0,(void*)0,&l_36,(void*)0,&l_36,(void*)0},{(void*)0,(void*)0,&l_466,(void*)0,(void*)0,(void*)0,&l_465,(void*)0,&g_363,(void*)0}},{{(void*)0,&g_21,&g_14,(void*)0,&l_635,&l_47,(void*)0,&g_21,&g_21,(void*)0},{&l_47,(void*)0,(void*)0,(void*)0,(void*)0,&l_47,&g_14,(void*)0,&l_47,(void*)0}},{{&l_47,(void*)0,&g_363,&l_465,(void*)0,&l_466,&l_465,&l_47,&l_467,&l_47},{&l_47,&l_47,&g_21,(void*)0,&g_21,&l_47,&l_47,&l_36,&l_47,(void*)0}},{{&l_47,&l_47,&l_36,&l_47,(void*)0,&l_47,&g_21,(void*)0,&l_36,&l_36},{(void*)0,&l_47,(void*)0,(void*)0,(void*)0,(void*)0,&l_47,(void*)0,&g_363,&l_465}},{{(void*)0,&l_47,&g_14,(void*)0,&l_47,(void*)0,&l_465,&l_47,&l_47,(void*)0},{&g_21,(void*)0,&g_14,&l_47,&g_131,&l_47,&g_14,(void*)0,&g_21,&g_14}},{{(void*)0,(void*)0,(void*)0,&l_465,(void*)0,&g_363,(void*)0,(void*)0,&g_221,&l_465},{&l_47,&g_21,&l_36,&l_465,&l_467,&l_467,&g_14,&g_221,&g_14,&l_47}},{{&g_221,&l_36,&g_14,(void*)0,&l_635,&g_363,&g_221,&l_47,&g_363,&g_14},{&l_36,&l_47,(void*)0,&l_36,&l_635,&l_465,&l_635,&l_36,(void*)0,&l_47}},{{&l_635,&g_221,&l_466,&g_21,&l_467,&l_466,&l_47,&g_14,&g_221,&g_14},{(void*)0,&l_36,&l_467,&g_363,(void*)0,&l_466,&l_466,(void*)0,&g_363,&l_467}},{{&l_635,&l_635,(void*)0,(void*)0,&l_47,&l_465,&g_21,&l_635,&g_131,&g_21},{&l_36,(void*)0,&l_466,&g_14,(void*)0,&g_363,&g_21,&g_363,(void*)0,&g_14}}};
                        int i, j, k;
                        if (l_854)
                            break;
                        g_221 |= (1UL > (l_854 ^= (safe_unary_minus_func_int32_t_s(((safe_mod_func_int32_t_s_s(((safe_mul_func_int16_t_s_s((safe_div_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u((((*l_636) ^= (((*l_556) && (((safe_mul_func_int16_t_s_s((+l_881), ((*l_552) = (safe_rshift_func_uint16_t_u_s((safe_rshift_func_int8_t_s_u(l_881, 7)), 8))))) || ((((*l_857) = (safe_mul_func_int16_t_s_s(l_888, (safe_mod_func_int32_t_s_s((((l_891 & ((**l_645) = (*g_648))) ^ (((safe_unary_minus_func_uint8_t_u(g_62[3][3])) != ((void*)0 == g_893)) || l_888)) ^ l_888), l_891))))) || (*l_556)) ^ 0xE5B7L)) != 0xB9FBD5A4L)) < (*l_556))) && l_888), l_839)), 0x6EL)), (*l_556))) ^ l_895), l_847)) && (*g_13))))));
                    }
                    for (g_198 = 0; (g_198 <= 1); g_198 += 1)
                    { /* block id: 482 */
                        uint32_t l_914 = 18446744073709551609UL;
                        (*l_749) = &l_839;
                        (**l_749) = (safe_sub_func_int8_t_s_s((-1L), ((l_466 &= (safe_add_func_uint32_t_u_u((*l_556), (((*l_627) = (1L | ((safe_mod_func_uint32_t_u_u(((safe_lshift_func_int8_t_s_s((l_839 <= ((safe_mul_func_uint8_t_u_u((((-1L) == (safe_lshift_func_int8_t_s_s(g_546[0][5], ((safe_mod_func_int64_t_s_s((g_62[1][1] , (((*l_626)--) == 0xCCB74ACC9A771608LL)), l_914)) || l_839)))) , 249UL), l_914)) && 0x264DL)), 2)) < 0UL), (**p_30))) , 18446744073709551608UL))) , (**g_894))))) , l_847)));
                    }
                }
            }
            else
            { /* block id: 490 */
                int8_t l_917 = 1L;
                uint64_t *l_935 = &g_315[1][3][2];
                int32_t l_936[9][8] = {{(-3L),(-1L),0x0C4D4B20L,9L,0xE978A14AL,0x0C4D4B20L,0xC6752597L,(-10L)},{0x79DF3135L,0xCACB5E0DL,0x0C4D4B20L,0xC9AB1B31L,0x7AD45BDEL,1L,0xCC277046L,0xCA2318ABL},{0xE978A14AL,2L,(-8L),0x1C425DD1L,0xC9AB1B31L,(-1L),0xDCCD0722L,0xDCCD0722L},{0x0C4D4B20L,0x7FE27681L,1L,1L,0x7FE27681L,0x0C4D4B20L,0xCA2318ABL,0xCC277046L},{0xDCCD0722L,0xC6752597L,(-3L),0x7FE27681L,0xCA2318ABL,0xCACB5E0DL,(-10L),0xC6752597L},{0xE978A14AL,(-10L),(-1L),0x7FE27681L,0xCC277046L,0x5B5E79F3L,0x1C425DD1L,0xCC277046L},{1L,0xCC277046L,0x7AD45BDEL,1L,0xE978A14AL,0xC6752597L,0xCDFAA9A5L,0xDCCD0722L},{(-10L),1L,1L,0x1C425DD1L,1L,1L,(-10L),0xCA2318ABL},{0L,0x79DF3135L,0xD7143BB4L,0xC9AB1B31L,(-1L),1L,0xC9AB1B31L,(-10L)}};
                int i, j;
                for (l_673 = 0; (l_673 != 18); ++l_673)
                { /* block id: 493 */
                    uint64_t l_918 = 18446744073709551615UL;
                    int16_t l_937 = 0xCDC8L;
                    --l_918;
                    for (l_635 = 1; (l_635 <= 6); l_635 += 1)
                    { /* block id: 497 */
                        uint32_t *l_923 = &g_66[7][1];
                        union U0 ***l_931 = &g_287;
                        int16_t *l_933 = (void*)0;
                        int16_t *l_934[9] = {&l_834[6][1],&l_642,&l_834[6][1],&l_834[6][1],&l_642,&l_834[6][1],&l_834[6][1],&l_642,&l_834[6][1]};
                        int32_t *l_938 = (void*)0;
                        int i, j;
                        if (g_66[(l_635 + 3)][l_635])
                            break;
                        g_221 |= (safe_mul_func_int8_t_s_s(((g_66[(l_635 + 1)][l_635] , (l_936[3][0] = (((g_66[(l_635 + 2)][l_635] , ((*l_923)--)) , ((((void*)0 != l_928) > ((((l_839 = (safe_mul_func_uint16_t_u_u((((*l_931) = &g_288) != &g_138), (l_918 | l_932)))) , &g_402) != l_935) >= g_14)) > g_66[(l_635 + 1)][l_635])) <= 0xDACAF3EDL))) > l_917), l_937));
                    }
                }
                return (*l_749);
            }
        }
        else
        { /* block id: 508 */
            for (g_295 = 0; g_295 < 2; g_295 += 1)
            {
                for (l_600 = 0; l_600 < 10; l_600 += 1)
                {
                    g_104[g_295][l_600] = (-1L);
                }
            }
            return (**g_893);
        }
    }
    else
    { /* block id: 512 */
        uint8_t *l_951 = &g_102;
        int32_t l_954 = 1L;
        int32_t *l_955 = (void*)0;
        int32_t *l_956 = (void*)0;
        int32_t *l_957[7] = {(void*)0,&l_36,(void*)0,(void*)0,&l_36,(void*)0,(void*)0};
        int8_t l_1072 = 2L;
        const int32_t *l_1114 = &l_36;
        int32_t ***l_1177[2];
        uint64_t ***l_1207 = &g_647;
        int8_t l_1221 = 0L;
        uint8_t *l_1228 = &g_423;
        int32_t ****l_1236 = (void*)0;
        int32_t *****l_1235 = &l_1236;
        int64_t **l_1237 = &l_636;
        int64_t *l_1238 = &g_145;
        int8_t *l_1246 = &g_127;
        int8_t **l_1245 = &l_1246;
        uint32_t l_1248 = 1UL;
        uint8_t *l_1249 = &l_1001;
        uint16_t *l_1256 = &g_169;
        int32_t l_1269 = 0x96B0C8F6L;
        uint16_t l_1270 = 1UL;
        int32_t l_1320 = 0x20F31736L;
        union U0 ****l_1352 = &g_1055;
        const int64_t *l_1370 = &g_1371[6];
        const int64_t **l_1369 = &l_1370;
        int i;
        for (i = 0; i < 2; i++)
            l_1177[i] = &g_894;
    }
    g_221 ^= (safe_mul_func_uint16_t_u_u(((l_1389 <= l_1390) < g_66[8][0]), ((*l_552) = ((((((*l_1391) = &g_1282[4]) != &g_1282[0]) <= ((l_1393[6] | ((safe_div_func_uint8_t_u_u(0xFFL, (((void*)0 != &l_1152) ^ g_1371[8]))) , 0UL)) ^ 0xB613L)) , 0xDB7E7A74L) >= 4294967295UL))));
    for (g_1386.f1 = (-15); (g_1386.f1 <= 19); g_1386.f1 = safe_add_func_int64_t_s_s(g_1386.f1, 1))
    { /* block id: 734 */
        uint64_t l_1423 = 1UL;
        uint8_t l_1444[3];
        union U0 ****l_1464 = &g_1055;
        int32_t l_1486 = 1L;
        int32_t l_1491 = 9L;
        int32_t l_1492 = (-1L);
        int32_t l_1496[8];
        int32_t l_1499 = 8L;
        uint32_t l_1503 = 5UL;
        int8_t **l_1522 = (void*)0;
        const int32_t ***l_1548 = (void*)0;
        int32_t ****l_1558[8][10][3] = {{{&l_1093[1][1],(void*)0,&g_893},{&l_1093[1][1],&l_1093[1][1],&g_893},{&g_893,&g_893,&l_1093[5][2]},{&l_1093[0][2],&g_893,(void*)0},{&g_893,(void*)0,&l_1093[1][1]},{&g_893,&g_893,&l_1093[1][2]},{&g_893,&g_893,&l_1093[1][1]},{&l_1093[1][1],&l_1093[5][1],(void*)0},{(void*)0,&g_893,&l_1093[5][2]},{&g_893,&l_1093[1][1],&g_893}},{{&g_893,&l_1093[1][1],&g_893},{&g_893,&g_893,&g_893},{&g_893,&l_1093[1][1],(void*)0},{(void*)0,&l_1093[1][1],&g_893},{&l_1093[1][1],&l_1093[1][1],&g_893},{(void*)0,&g_893,&l_1093[1][1]},{&g_893,&l_1093[1][1],&l_1093[5][0]},{&g_893,&l_1093[1][1],&l_1093[6][5]},{&l_1093[6][5],&g_893,&l_1093[5][2]},{&g_893,&l_1093[1][1],&g_893}},{{&l_1093[1][1],&l_1093[1][1],&g_893},{&l_1093[1][1],&l_1093[1][1],(void*)0},{&l_1093[1][1],(void*)0,&l_1093[7][1]},{&l_1093[5][2],(void*)0,&l_1093[5][1]},{&l_1093[1][2],&g_893,&l_1093[1][2]},{&l_1093[1][1],&l_1093[1][1],&l_1093[5][0]},{&g_893,(void*)0,&g_893},{&g_893,&l_1093[2][4],&l_1093[1][1]},{&l_1093[6][5],&l_1093[1][1],&l_1093[1][1]},{&g_893,&g_893,&l_1093[1][1]}},{{&g_893,(void*)0,&l_1093[1][1]},{&l_1093[1][1],&l_1093[1][1],&g_893},{&l_1093[1][2],&l_1093[1][1],&l_1093[1][1]},{&l_1093[5][2],&g_893,&l_1093[2][3]},{&l_1093[1][1],(void*)0,(void*)0},{&l_1093[1][1],&g_893,&g_893},{&l_1093[1][1],&g_893,&l_1093[1][1]},{&g_893,&g_893,&l_1093[1][1]},{&l_1093[6][5],&l_1093[1][1],&l_1093[5][0]},{&g_893,&g_893,&l_1093[5][0]}},{{&g_893,&l_1093[1][1],&l_1093[1][1]},{(void*)0,&l_1093[1][1],&l_1093[1][1]},{&l_1093[1][1],&l_1093[5][0],&g_893},{(void*)0,&g_893,(void*)0},{&l_1093[5][0],&l_1093[1][2],&l_1093[2][3]},{&g_893,&l_1093[1][1],&l_1093[1][1]},{&g_893,&g_893,&g_893},{&l_1093[1][1],&g_893,&l_1093[1][1]},{&l_1093[1][1],&l_1093[5][5],&l_1093[1][1]},{(void*)0,&l_1093[0][2],&l_1093[1][1]}},{{&g_893,&g_893,&l_1093[1][1]},{&g_893,&l_1093[0][2],&g_893},{&l_1093[2][4],&l_1093[5][5],&l_1093[5][0]},{&g_893,&g_893,&l_1093[1][2]},{&l_1093[1][1],&g_893,&l_1093[5][1]},{(void*)0,&l_1093[1][1],&l_1093[7][1]},{&g_893,&l_1093[1][2],(void*)0},{&l_1093[2][3],&g_893,&g_893},{&g_893,&l_1093[5][0],&g_893},{&l_1093[1][1],&l_1093[1][1],&l_1093[5][2]}},{{&g_893,&l_1093[1][1],&l_1093[6][5]},{&l_1093[1][1],&g_893,&l_1093[5][0]},{&l_1093[1][1],&l_1093[1][1],&l_1093[1][1]},{&g_893,&g_893,&g_893},{&l_1093[1][1],&g_893,&g_893},{&g_893,&g_893,(void*)0},{&l_1093[2][3],(void*)0,&l_1093[1][1]},{&g_893,&g_893,&g_893},{(void*)0,&l_1093[1][1],&l_1093[1][1]},{&l_1093[1][1],&l_1093[1][1],&g_893}},{{&g_893,(void*)0,&l_1093[1][1]},{&l_1093[2][4],&g_893,(void*)0},{&g_893,&l_1093[1][1],&l_1093[1][1]},{&g_893,&l_1093[2][4],(void*)0},{(void*)0,(void*)0,&l_1093[1][1]},{&l_1093[1][1],&l_1093[1][1],&l_1093[2][4]},{&l_1093[6][5],(void*)0,&g_893},{&l_1093[1][1],&l_1093[1][1],&g_893},{&l_1093[1][1],&g_893,&l_1093[6][5]},{&g_893,(void*)0,&l_1093[1][1]}}};
        uint16_t l_1575 = 65531UL;
        uint16_t l_1605[10][8][3] = {{{0x3315L,0x757DL,1UL},{0x5D82L,3UL,0UL},{0x2D3FL,0x67EFL,1UL},{2UL,0x67EFL,0x055CL},{3UL,3UL,0xDD04L},{65535UL,0x757DL,0x6AECL},{0xDBC4L,0x5D82L,65535UL},{3UL,65535UL,0x145FL}},{{65530UL,0xB823L,65526UL},{65526UL,8UL,65533UL},{0x49FCL,0x2BD0L,0xB823L},{0x3C20L,0xA3A3L,65526UL},{0x79E8L,0xD24FL,0x86EDL},{0x7C7BL,0xB9EBL,0xDBC4L},{65535UL,65535UL,0x253CL},{65534UL,7UL,65535UL}},{{0xF0C1L,0xF0C1L,0x79E8L},{7UL,0x3C20L,0UL},{0x055CL,65535UL,0UL},{65535UL,65526UL,0x8E1AL},{0x6C74L,0x055CL,0UL},{3UL,0UL,0UL},{0xDD04L,1UL,0x79E8L},{0x88A1L,3UL,65535UL}},{{1UL,5UL,0x253CL},{0xC186L,1UL,0xDBC4L},{0UL,65535UL,0x86EDL},{0UL,0x9794L,65526UL},{1UL,0x6AECL,0xB823L},{65535UL,0xC186L,65533UL},{0x757DL,65533UL,65526UL},{0x9794L,65532UL,0x145FL}},{{0x60B3L,65529UL,65535UL},{1UL,0UL,0x6AECL},{0UL,0x3B15L,0xDD04L},{65526UL,65529UL,0x055CL},{0x221FL,0x7C7BL,1UL},{0x221FL,0UL,0UL},{65526UL,0x94BEL,1UL},{0UL,1UL,65529UL}},{{1UL,0x145FL,1UL},{0x60B3L,65535UL,0x704EL},{0x9794L,0x88A1L,0UL},{0x757DL,0x1718L,65535UL},{65535UL,65533UL,65530UL},{1UL,65532UL,1UL},{0UL,0UL,0xA3A3L},{0UL,0UL,3UL}},{{0xC186L,0x8E1AL,0x3B15L},{1UL,7UL,7UL},{0x88A1L,0x6C74L,1UL},{0xDD04L,0x704EL,0x962DL},{3UL,3UL,0xD8B6L},{0x6C74L,1UL,0x9794L},{65535UL,3UL,0xFAEEL},{0x055CL,0x704EL,1UL}},{{7UL,0x6C74L,65533UL},{0xF0C1L,7UL,0x831DL},{65534UL,0x8E1AL,0x2BD0L},{65535UL,65535UL,65532UL},{0x939EL,0x6AECL,0x60B3L},{0x704EL,0x79E8L,65526UL},{0UL,2UL,0UL},{0xB823L,0x9794L,65535UL}},{{0x3315L,65535UL,1UL},{0UL,65535UL,65535UL},{1UL,0xFAEEL,1UL},{0x2BD0L,0xD24FL,1UL},{65535UL,0x2005L,0xC40BL},{0xF0C1L,65533UL,0xC186L},{65529UL,0x939EL,0xC186L},{65526UL,3UL,0xC40BL}},{{0x3B15L,65527UL,1UL},{0UL,0xD7E6L,1UL},{0x8345L,0xA470L,65535UL},{3UL,0x253CL,1UL},{0x831DL,1UL,65535UL},{0x79E8L,65535UL,0UL},{5UL,0xE1B3L,65526UL},{1UL,0x221FL,0x60B3L}}};
        int16_t *l_1684[8] = {&l_1594,&l_1594,&g_295,&l_1594,&l_1594,&g_295,&l_1594,&l_1594};
        int32_t l_1729 = (-8L);
        uint32_t l_1768[1];
        int8_t l_1769 = 5L;
        int32_t *l_1800 = &l_467;
        int64_t ***l_1818 = (void*)0;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_1444[i] = 0x4CL;
        for (i = 0; i < 8; i++)
            l_1496[i] = 0x25EE5C19L;
        for (i = 0; i < 1; i++)
            l_1768[i] = 18446744073709551615UL;
        for (g_169 = 0; (g_169 <= 7); g_169 += 1)
        { /* block id: 737 */
            int32_t l_1424[9];
            int32_t l_1429 = 4L;
            int32_t ***l_1443 = &g_894;
            int16_t *l_1468 = &g_295;
            int32_t l_1493 = 0x135D8FF0L;
            int32_t l_1495 = 2L;
            int32_t l_1498[6][7] = {{8L,0L,0x4DCB9607L,0x2D6B9D07L,0x083B4AA5L,8L,0xF4BA2D24L},{9L,(-10L),4L,0xF4BA2D24L,8L,0x47D27FA5L,0x47D27FA5L},{4L,0x66CD088DL,0x4DCB9607L,0x66CD088DL,4L,1L,0x216F5F87L},{0x216F5F87L,0x66CD088DL,7L,0L,0x2D6B9D07L,0L,8L},{0x66CD088DL,(-10L),0x2D6B9D07L,0x5EEECA9AL,0x4DCB9607L,0x4DCB9607L,0x5EEECA9AL},{0x216F5F87L,0L,0x216F5F87L,0x4DCB9607L,8L,(-10L),0x5EEECA9AL}};
            int i, j;
            for (i = 0; i < 9; i++)
                l_1424[i] = (-10L);
            for (g_198 = 0; (g_198 <= 7); g_198 += 1)
            { /* block id: 740 */
                const uint64_t l_1404[6] = {0x909DB8DC516F30DDLL,0x16A9EDECAD1E9EC6LL,0x909DB8DC516F30DDLL,0x909DB8DC516F30DDLL,0x16A9EDECAD1E9EC6LL,0x909DB8DC516F30DDLL};
                const uint16_t *l_1463 = &g_222;
                int32_t l_1465 = (-1L);
                int16_t *l_1469[8][2] = {{&l_834[1][2],&l_834[1][2]},{&l_834[6][1],(void*)0},{&g_625,(void*)0},{&l_834[6][1],&l_834[1][2]},{&l_834[1][2],&l_834[6][1]},{(void*)0,&g_625},{(void*)0,&l_834[6][1]},{&l_834[1][2],&l_834[1][2]}};
                int32_t l_1487 = 0xBCAC1280L;
                int32_t l_1490 = 1L;
                int32_t l_1494[8] = {0x098128DDL,0x098128DDL,0x098128DDL,0x098128DDL,0x098128DDL,0x098128DDL,0x098128DDL,0x098128DDL};
                int i, j;
                for (l_468 = 5; (l_468 >= 0); l_468 -= 1)
                { /* block id: 743 */
                    uint32_t l_1425 = 18446744073709551615UL;
                    int32_t l_1426 = 0x4FAC4B68L;
                    for (g_127 = 0; (g_127 <= 6); g_127 += 1)
                    { /* block id: 746 */
                        int i, j;
                        g_131 &= (safe_mod_func_uint8_t_u_u((l_1145[(g_198 + 2)] , g_66[(l_468 + 3)][g_127]), ((*l_689)++)));
                    }
                    for (g_289.f2 = 9; (g_289.f2 >= 1); g_289.f2 -= 1)
                    { /* block id: 752 */
                        int i;
                        if (l_1145[(l_468 + 2)])
                            break;
                        l_1426 &= ((((*l_552) = ((safe_div_func_uint32_t_u_u((l_1404[2] >= (((safe_unary_minus_func_int8_t_s(((safe_sub_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((*g_648), ((safe_rshift_func_int16_t_s_s((safe_add_func_int64_t_s_s((((*l_626) = ((((g_1414 < (safe_lshift_func_uint16_t_u_s((+((g_1048 <= (safe_sub_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(l_1404[3], 9)), l_1421))) > l_1404[2])), 6))) , ((*g_648) ^ (((l_1422 != (void*)0) ^ 0x92C8BFB5L) == (*g_1247)))) >= l_1145[(l_468 + 2)]) | l_1404[2])) && 1UL), (-2L))), 8)) & (**p_30)))), l_1145[(l_468 + 2)])) != l_1423))) == 0x8606L) || l_1424[1])), (-1L))) , 0UL)) ^ l_1425) > g_1371[4]);
                        (*p_30) = &l_1145[(l_468 + 2)];
                    }
                }
                for (l_468 = 0; (l_468 <= 7); l_468 += 1)
                { /* block id: 762 */
                    uint8_t *l_1438 = (void*)0;
                    uint8_t **l_1439 = &l_1438;
                    int32_t l_1442[2][5] = {{1L,1L,1L,1L,1L},{(-1L),0xD87F2667L,(-1L),0xD87F2667L,(-1L)}};
                    int i, j;
                    l_1429 = (safe_sub_func_uint8_t_u_u(0x36L, ((*g_1247) &= (-3L))));
                }
                l_1486 ^= 0xE6174DB6L;
            }
        }
        for (g_1048 = 0; (g_1048 != 9); g_1048++)
        { /* block id: 792 */
            int8_t l_1532 = 1L;
            for (l_1251 = (-5); (l_1251 <= 8); l_1251 = safe_add_func_uint64_t_u_u(l_1251, 3))
            { /* block id: 795 */
                int8_t * const * const l_1517 = &g_1247;
                int8_t *l_1529 = (void*)0;
                int8_t *l_1530[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                uint32_t l_1531 = 1UL;
                int i;
                l_1496[4] = ((safe_add_func_int16_t_s_s((safe_div_func_int16_t_s_s((safe_unary_minus_func_uint8_t_u((!((((safe_add_func_int32_t_s_s((**p_30), (8L != (**p_30)))) <= ((*g_1247) ^= (l_1517 != ((safe_lshift_func_uint16_t_u_s(0xA3CAL, (safe_div_func_int64_t_s_s(0x9684DE4468F89D76LL, (-3L))))) , l_1522)))) | ((safe_mul_func_int8_t_s_s((safe_lshift_func_int8_t_s_u((l_1531 ^= (safe_mul_func_uint16_t_u_u(0x0093L, l_1496[0]))), g_62[0][3])), l_1532)) != 0x3073L)) || l_1532)))), 1UL)), l_1503)) || l_1532);
            }
        }
        l_1499 = 0x784D349BL;
        for (g_169 = 2; (g_169 <= 6); g_169 += 1)
        { /* block id: 804 */
            int32_t l_1542 = 0xF994A69AL;
            uint32_t **l_1550 = (void*)0;
            int32_t l_1551 = 8L;
            int32_t l_1586 = 0x8E819FA9L;
            union U0 * const l_1591 = &g_1592[0][4][1];
            int16_t *l_1626 = &g_615;
            uint8_t l_1628[3][7] = {{2UL,0xCDL,0x91L,0x91L,0xCDL,2UL,0xCDL},{5UL,2UL,2UL,5UL,0xCDL,5UL,2UL},{1UL,1UL,2UL,0x91L,2UL,1UL,1UL}};
            int16_t l_1629 = 1L;
            int32_t l_1632 = 0x8DBD52B5L;
            int16_t *l_1808[8] = {&g_615,&g_615,&g_615,&g_615,&g_615,&g_615,&g_615,&g_615};
            int8_t ** const l_1830 = (void*)0;
            int i, j;
        }
    }
    return (**g_893);
}


/* ------------------------------------------ */
/* 
 * reads : g_169 g_62 g_13 g_14 g_289.f1 g_312 g_147 g_127 g_287 g_288 g_423 g_221 g_90.f2 g_315 g_69 g_131 g_363
 * writes: g_169 g_222 g_289.f1 g_363 g_104 g_127 g_288 g_21 g_312 g_315 g_423 g_221 g_198 g_90.f2 g_69 g_131
 */
static uint16_t  func_37(uint64_t  p_38, int32_t * p_39, int64_t  p_40, uint32_t  p_41)
{ /* block id: 175 */
    const uint64_t *l_401[4];
    const uint64_t *l_403 = (void*)0;
    uint32_t l_407 = 1UL;
    int32_t l_411 = 0L;
    int32_t l_421 = 8L;
    int32_t l_456 = (-3L);
    int32_t l_457 = 7L;
    int i;
    for (i = 0; i < 4; i++)
        l_401[i] = &g_402;
    for (g_169 = 1; (g_169 <= 6); g_169 += 1)
    { /* block id: 178 */
        int8_t *l_378 = &g_289.f1;
        const int32_t l_383[4] = {0L,0L,0L,0L};
        int32_t *l_388 = &g_363;
        int16_t *l_397 = &g_104[1][6];
        const uint64_t *l_399 = &g_400;
        const uint64_t **l_398[6][10][4] = {{{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399}},{{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399}},{{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399}},{{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399}},{{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,(void*)0,&l_399},{(void*)0,&l_399,&l_399,&l_399},{(void*)0,&l_399,(void*)0,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{(void*)0,&l_399,&l_399,&l_399}},{{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{(void*)0,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{(void*)0,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{&l_399,&l_399,&l_399,&l_399},{(void*)0,&l_399,&l_399,&l_399}}};
        int32_t *l_404 = (void*)0;
        int32_t *l_405 = &g_363;
        const int64_t l_406 = (-8L);
        int32_t l_412[7];
        union U0 ** const *l_427 = (void*)0;
        int8_t *l_436 = &g_90.f1;
        int16_t l_455[8] = {0xC656L,(-3L),0xC656L,(-3L),0xC656L,(-3L),0xC656L,(-3L)};
        uint8_t l_460 = 0x53L;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_412[i] = 1L;
        for (g_222 = 0; (g_222 <= 1); g_222 += 1)
        { /* block id: 181 */
            union U0 ***l_375 = &g_287;
            int32_t l_384 = 0x6E27FC08L;
            int32_t *l_385 = &g_363;
            int i, j;
            (*l_385) = ((g_62[g_169][(g_169 + 1)] ^ ((safe_rshift_func_int8_t_s_u((p_40 , ((*l_378) ^= (safe_mul_func_int16_t_s_s((((safe_mul_func_uint16_t_u_u((((((l_375 = l_375) != (void*)0) & (safe_lshift_func_int8_t_s_u(p_38, (((void*)0 == l_378) , 251UL)))) && (l_384 |= ((safe_lshift_func_int8_t_s_s((safe_sub_func_int32_t_s_s(0x661C0887L, (*g_13))), l_383[1])) & 0x735C65E0L))) > p_40), p_41)) && p_40) < 0L), 0x0B3FL)))), l_383[1])) , g_312)) && g_147);
            return g_169;
        }
        l_388 = ((safe_lshift_func_uint8_t_u_s(l_383[1], 6)) , p_39);
        (*l_405) = (safe_mul_func_int8_t_s_s((safe_div_func_int16_t_s_s((-1L), ((*l_397) = (safe_lshift_func_int8_t_s_s((safe_lshift_func_uint16_t_u_s(65533UL, 7)), 5))))), (((l_401[1] = (void*)0) == l_403) | (*l_388))));
        for (g_127 = 0; (g_127 <= 1); g_127 += 1)
        { /* block id: 194 */
            int32_t *l_410 = &g_363;
            int32_t l_419 = 0x6713A917L;
            int32_t l_420 = (-10L);
            int32_t l_422 = 1L;
            (*g_287) = (*g_287);
            l_407 = l_406;
            for (g_21 = 5; (g_21 >= 0); g_21 -= 1)
            { /* block id: 199 */
                int32_t **l_408 = &l_388;
                int32_t **l_409 = &l_404;
                int32_t *l_413 = (void*)0;
                int32_t *l_414 = &g_131;
                int32_t *l_415 = &g_221;
                int32_t *l_416 = &g_131;
                int32_t *l_417 = &l_412[0];
                int32_t *l_418[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_418[i] = &l_412[3];
                (*l_409) = ((*l_408) = &g_221);
                for (g_289.f1 = 0; g_289.f1 < 2; g_289.f1 += 1)
                {
                    for (g_363 = 0; g_363 < 8; g_363 += 1)
                    {
                        for (g_312 = 0; g_312 < 9; g_312 += 1)
                        {
                            g_315[g_289.f1][g_363][g_312] = 6UL;
                        }
                    }
                }
                l_410 = &g_131;
                g_423--;
            }
            for (l_420 = 1; (l_420 >= 0); l_420 -= 1)
            { /* block id: 208 */
                uint16_t l_450 = 0xF09DL;
                int16_t l_451[2];
                int32_t l_452[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_451[i] = 8L;
                for (i = 0; i < 2; i++)
                    l_452[i] = (-1L);
                for (g_221 = 1; (g_221 >= 0); g_221 -= 1)
                { /* block id: 211 */
                    for (g_198 = 0; (g_198 <= 1); g_198 += 1)
                    { /* block id: 214 */
                        int32_t **l_426 = (void*)0;
                        l_405 = &g_363;
                    }
                    for (g_90.f2 = 1; (g_90.f2 >= 0); g_90.f2 -= 1)
                    { /* block id: 219 */
                        int i, j, k;
                        return g_315[g_221][(g_90.f2 + 6)][(g_127 + 5)];
                    }
                }
                if ((&g_287 != l_427))
                { /* block id: 223 */
                    const int32_t *l_429 = &l_421;
                    int8_t **l_434 = (void*)0;
                    int8_t **l_435 = &l_378;
                    uint64_t *l_441 = &g_312;
                    for (g_69 = 0; (g_69 <= 1); g_69 += 1)
                    { /* block id: 226 */
                        const int32_t **l_428 = (void*)0;
                        int i, j, k;
                        l_429 = &g_28;
                        if (g_315[g_69][(g_69 + 2)][(g_127 + 7)])
                            break;
                        (*l_405) = g_315[l_420][(g_69 + 1)][(g_127 + 2)];
                        if (g_315[g_69][(g_127 + 2)][(l_420 + 7)])
                            continue;
                    }
                    l_452[0] = ((safe_mod_func_uint32_t_u_u(0x55DCB15FL, ((safe_add_func_int64_t_s_s((((*l_435) = &g_147) == l_436), (safe_sub_func_uint32_t_u_u(((safe_div_func_int64_t_s_s(1L, g_315[1][3][2])) == (((((*l_410) = (--(*l_441))) | 4UL) && ((safe_mul_func_uint8_t_u_u((safe_rshift_func_int8_t_s_s(((safe_rshift_func_uint16_t_u_s(((*l_410) < l_450), l_451[1])) , p_40), 4)), g_363)) > 0x2C64FA1B566AA79ELL)) || 0xD6L)), 0x490D06F9L)))) && (-3L)))) < 0x8101L);
                }
                else
                { /* block id: 236 */
                    int32_t *l_453 = &l_411;
                    int32_t *l_454[1][6] = {{&l_452[0],&g_363,&g_363,&l_452[0],&g_363,&g_363}};
                    int8_t l_458[5][4][7] = {{{(-10L),9L,9L,(-10L),0x19L,1L,(-1L)},{0x0AL,(-3L),(-1L),1L,4L,0x0AL,0x0AL},{(-10L),(-1L),2L,(-1L),(-10L),0x3FL,(-1L)},{(-5L),(-8L),5L,4L,(-1L),5L,9L}},{{9L,0x90L,0x85L,0x85L,0x90L,9L,0x19L},{(-5L),4L,(-2L),(-5L),9L,0x19L,4L},{(-10L),0x3CL,9L,0x61L,9L,0x3CL,(-10L)},{0x0AL,4L,1L,(-1L),(-3L),0x0AL,(-1L)}},{{(-10L),0x90L,(-3L),(-1L),(-1L),(-3L),0x90L},{4L,(-8L),1L,0x39L,(-8L),(-1L),9L},{1L,(-1L),9L,1L,0x90L,1L,9L},{(-3L),(-3L),(-2L),0x39L,4L,0xFCL,(-3L)}},{{(-10L),9L,0x85L,(-1L),0x3CL,0x3CL,(-1L)},{5L,9L,5L,(-1L),4L,5L,(-8L)},{(-1L),0x90L,2L,0x61L,0x90L,0L,0x90L},{(-5L),(-1L),(-1L),(-5L),(-8L),5L,4L}},{{0x3CL,(-10L),9L,0x85L,(-1L),0x3CL,0x3CL},{(-3L),4L,7L,4L,(-3L),0xFCL,5L},{0x85L,0x3FL,2L,1L,(-3L),2L,0x3CL},{0x19L,0x0AL,0x9EL,0x9EL,0x0AL,0x19L,0xFCL}}};
                    int i, j, k;
                    --l_460;
                }
            }
        }
    }
    return l_407;
}


/* ------------------------------------------ */
/* 
 * reads : g_62 g_23 g_13 g_14 g_66 g_21 g_102 g_93.f1 g_90.f1 g_138 g_90.f2 g_149 g_104 g_169 g_145 g_69 g_131 g_147 g_198 g_222 g_221 g_127 g_287 g_295 g_289.f1 g_28 g_67 g_289.f2 g_288 g_315 g_345 g_312 g_366
 * writes: g_62 g_66 g_67 g_69 g_21 g_102 g_104 g_90.f2 g_149 g_169 g_145 g_93.f1 g_147 g_198 g_222 g_127 g_287 g_289.f1 g_295 g_312 g_315 g_289.f2 g_288 g_340.f1 g_345 g_366 g_14
 */
static int32_t  func_42(int8_t  p_43, int32_t * p_44)
{ /* block id: 17 */
    int8_t l_60[9] = {(-7L),0xCCL,(-7L),0xCCL,(-7L),0xCCL,(-7L),0xCCL,(-7L)};
    uint32_t *l_61 = &g_62[0][3];
    uint32_t *l_65[7][9][4] = {{{&g_66[2][2],&g_66[7][1],(void*)0,&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][3],&g_66[8][3]},{&g_66[7][1],(void*)0,&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[9][3]},{&g_66[9][5],(void*)0,&g_66[7][1],(void*)0},{&g_66[7][1],&g_66[7][1],&g_66[7][1],(void*)0},{&g_66[9][5],&g_66[1][5],(void*)0,&g_66[7][1]},{&g_66[9][3],&g_66[9][5],&g_66[7][1],&g_66[7][1]},{&g_66[9][3],&g_66[2][2],(void*)0,&g_66[9][5]}},{{&g_66[9][5],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[3][1],&g_66[7][1],(void*)0},{&g_66[9][5],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[1][5]},{&g_66[7][1],&g_66[0][2],&g_66[7][3],(void*)0},{&g_66[7][1],&g_66[7][1],(void*)0,&g_66[7][3]},{&g_66[2][2],&g_66[7][1],&g_66[7][1],(void*)0},{&g_66[7][1],&g_66[0][2],(void*)0,&g_66[1][5]},{(void*)0,&g_66[7][1],&g_66[7][1],&g_66[7][1]}},{{&g_66[7][1],&g_66[7][1],&g_66[7][1],(void*)0},{&g_66[0][2],&g_66[3][1],&g_66[0][2],&g_66[7][1]},{(void*)0,&g_66[7][1],&g_66[9][5],&g_66[9][5]},{(void*)0,&g_66[2][2],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[9][5],&g_66[7][1],&g_66[7][1]},{(void*)0,&g_66[1][5],&g_66[9][5],(void*)0},{(void*)0,&g_66[7][1],&g_66[0][2],(void*)0},{&g_66[0][2],(void*)0,&g_66[7][1],&g_66[9][3]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[7][1]}},{{(void*)0,(void*)0,(void*)0,&g_66[8][3]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[2][2],&g_66[7][1],(void*)0,&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][3],&g_66[8][3]},{&g_66[7][1],(void*)0,&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[9][3]},{&g_66[9][5],(void*)0,&g_66[7][1],(void*)0},{&g_66[7][1],&g_66[7][1],&g_66[7][1],(void*)0},{&g_66[9][5],&g_66[1][5],(void*)0,&g_66[7][1]}},{{&g_66[9][3],&g_66[9][5],&g_66[7][1],&g_66[7][1]},{&g_66[9][3],&g_66[2][2],(void*)0,&g_66[9][5]},{&g_66[9][5],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[3][1],&g_66[7][1],(void*)0},{&g_66[9][5],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[2][2]},{&g_66[9][3],&g_66[7][1],&g_66[7][1],&g_66[7][3]},{&g_66[9][5],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[7][3]}},{{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[2][2]},{&g_66[9][5],&g_66[8][3],&g_66[9][3],(void*)0},{&g_66[7][1],(void*)0,&g_66[7][1],&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[8][3]},{&g_66[7][1],&g_66[7][1],(void*)0,&g_66[7][1]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[7][1]},{&g_66[7][1],(void*)0,&g_66[7][1],&g_66[9][3]},{&g_66[7][1],&g_66[2][2],(void*)0,&g_66[7][1]},{&g_66[7][1],&g_66[0][2],&g_66[7][1],&g_66[7][1]}},{{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[1][5]},{&g_66[7][1],&g_66[9][3],&g_66[9][3],&g_66[7][1]},{&g_66[9][5],&g_66[7][3],&g_66[7][1],(void*)0},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[0][2]},{&g_66[7][1],&g_66[7][1],&g_66[7][1],&g_66[0][2]},{&g_66[9][5],&g_66[7][1],&g_66[7][1],(void*)0},{&g_66[9][3],&g_66[7][3],&g_66[9][5],&g_66[7][1]},{&g_66[8][3],&g_66[9][3],(void*)0,&g_66[1][5]},{(void*)0,&g_66[7][1],(void*)0,&g_66[7][1]}}};
    uint32_t *l_68 = &g_69;
    union U0 ***l_290 = &g_287;
    int16_t l_296 = 3L;
    int8_t *l_297 = &g_289.f1;
    int32_t l_298 = (-1L);
    const int32_t *l_300 = &g_28;
    const int32_t **l_299[9][8][2] = {{{&l_300,&l_300},{(void*)0,&l_300},{(void*)0,&l_300},{&l_300,&l_300},{&l_300,&l_300},{(void*)0,&l_300},{&l_300,&l_300},{&l_300,&l_300}},{{&l_300,&l_300},{&l_300,&l_300},{&l_300,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_300},{&l_300,(void*)0},{&l_300,&l_300},{&l_300,(void*)0}},{{&l_300,&l_300},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300}},{{(void*)0,&l_300},{&l_300,&l_300},{&l_300,&l_300},{(void*)0,&l_300},{(void*)0,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,(void*)0}},{{&l_300,&l_300},{&l_300,(void*)0},{&l_300,&l_300},{(void*)0,&l_300},{&l_300,(void*)0},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300}},{{&l_300,&l_300},{(void*)0,(void*)0},{&l_300,&l_300},{&l_300,(void*)0},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{(void*)0,&l_300}},{{(void*)0,&l_300},{&l_300,&l_300},{(void*)0,&l_300},{(void*)0,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300}},{{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{(void*)0,&l_300},{&l_300,(void*)0},{&l_300,&l_300}},{{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,&l_300},{&l_300,(void*)0},{&l_300,(void*)0},{&l_300,&l_300},{&l_300,&l_300}}};
    union U0 **l_358 = &g_288;
    int32_t l_364 = 0x5DAA8CFCL;
    int32_t l_365[7] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    int i, j, k;
    (*l_358) = (((safe_mod_func_uint32_t_u_u((~(((*p_44) = func_50((0x58AF3265L <= (safe_mod_func_int64_t_s_s(((safe_sub_func_uint64_t_u_u((p_43 ^ ((((safe_unary_minus_func_int32_t_s((((((*l_68) = (l_60[1] <= (g_67 = (g_66[0][1] = (++(*l_61)))))) , ((*l_297) |= (~((func_70(g_23) == (safe_div_func_int64_t_s_s(((safe_lshift_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(((((safe_rshift_func_uint8_t_u_u(l_60[8], (((*l_290) = g_287) != &g_138))) < ((safe_mod_func_int32_t_s_s((((safe_lshift_func_uint16_t_u_u(g_14, 2)) , &g_131) != &g_221), 4L)) >= l_60[4])) ^ 1UL) ^ g_66[7][1]), g_295)), l_60[7])) & 0xE1AAL), l_296))) < 2L)))) | g_28) > 0x4FF3L))) < l_298) , l_296) , l_296)), 0L)) , p_43), (-3L)))), p_44, p_43, l_299[8][0][0])) ^ 8UL)), g_23)) ^ (*l_300)) , (void*)0);
    for (g_312 = 23; (g_312 != 21); g_312--)
    { /* block id: 171 */
        int32_t *l_361 = &g_21;
        int32_t *l_362[1][8] = {{&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21}};
        int i, j;
        g_366++;
    }
    return (*g_13);
}


/* ------------------------------------------ */
/* 
 * reads : g_295 g_21 g_131 g_221 g_90.f1 g_222 g_67 g_104 g_289.f2 g_287 g_288 g_149 g_315 g_62 g_13 g_14 g_345
 * writes: g_295 g_21 g_312 g_222 g_315 g_102 g_289.f2 g_288 g_340.f1 g_345 g_14
 */
static int32_t  func_50(int64_t  p_51, int32_t * p_52, int8_t  p_53, const int32_t ** p_54)
{ /* block id: 139 */
    uint32_t l_301 = 0xE0DB0FBAL;
    int32_t l_344[3][9] = {{0L,0L,(-5L),0x924941D3L,(-9L),(-2L),0x0A9D3A49L,(-2L),(-9L)},{(-5L),0L,0L,(-5L),0x924941D3L,(-9L),(-2L),0x0A9D3A49L,(-2L)},{0x0A9D3A49L,0x1CDF39E8L,(-5L),(-5L),0x1CDF39E8L,0x0A9D3A49L,(-7L),0L,(-5L)}};
    uint16_t l_353 = 0xE36FL;
    int i, j;
    if (l_301)
    { /* block id: 140 */
        int32_t l_304[3];
        int32_t **l_321[2][4] = {{&g_13,&g_13,&g_13,&g_13},{&g_13,&g_13,&g_13,&g_13}};
        uint8_t *l_322[5][4][9] = {{{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102}},{{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102,&g_102,&g_102,&g_102}},{{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102}},{{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102,(void*)0,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,(void*)0,&g_102,(void*)0,&g_102,&g_102,&g_102,&g_102}},{{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,(void*)0,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,(void*)0},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102}}};
        int8_t *l_325 = &g_289.f2;
        union U0 *l_339 = &g_340;
        union U0 **l_341 = &l_339;
        uint64_t l_342 = 0x77C499EDAFD709BBLL;
        int8_t *l_343 = &g_340.f1;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_304[i] = 1L;
        for (g_295 = 25; (g_295 <= 17); g_295 = safe_sub_func_int8_t_s_s(g_295, 2))
        { /* block id: 143 */
            uint64_t *l_311 = &g_312;
            uint16_t *l_313 = &g_222;
            uint64_t *l_314 = &g_315[1][3][2];
            uint8_t *l_318 = &g_102;
            (*p_52) |= (1L & 0xA6105551L);
            (*p_52) ^= (((((g_131 <= 0x2497L) , (&g_288 == (void*)0)) > l_304[2]) >= (safe_lshift_func_int16_t_s_s((((*l_314) = (safe_rshift_func_uint16_t_u_s(((*l_313) |= (~(safe_mod_func_uint64_t_u_u(g_221, ((*l_311) = g_90.f1))))), 1))) , 0x91AEL), 1))) < (((*l_318) = (safe_mul_func_int8_t_s_s(g_67, g_104[0][2]))) , 0x0F0AC8ABL));
        }
        (*p_52) &= (safe_lshift_func_int16_t_s_s(g_104[1][9], l_301));
        (*p_52) &= (l_321[1][3] == (void*)0);
        (*p_52) = ((((g_102 = 0xCAL) | ((safe_rshift_func_int8_t_s_s((l_301 , ((*l_325) ^= p_51)), 6)) | (l_344[0][5] &= ((*l_343) = ((safe_div_func_int64_t_s_s((safe_add_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_add_func_int64_t_s_s(0xEFE3EA39F0464915LL, (safe_unary_minus_func_uint8_t_u(((safe_lshift_func_int8_t_s_u((safe_rshift_func_uint16_t_u_u(((((*g_287) = (*g_287)) == ((*l_341) = l_339)) != ((0x5EL == p_53) >= g_149)), g_315[1][1][0])), g_62[0][3])) ^ (*g_13)))))), (*g_13))), l_342)), 6L)) < 0x644EL))))) | 9UL) & 4294967287UL);
    }
    else
    { /* block id: 160 */
        int32_t *l_346 = &l_344[0][5];
        int32_t *l_347 = &g_21;
        int32_t *l_348 = &g_131;
        int32_t *l_349 = &g_21;
        int32_t *l_350 = &g_21;
        int32_t *l_351 = &g_21;
        int32_t *l_352 = &g_221;
        int32_t **l_356 = (void*)0;
        int32_t **l_357 = &l_348;
        g_345 = (void*)0;
        l_353++;
        (*l_357) = l_347;
        return (*l_349);
    }
    return (*g_345);
}


/* ------------------------------------------ */
/* 
 * reads : g_13 g_14 g_66 g_21 g_23 g_62 g_102 g_93.f1 g_90.f1 g_138 g_90.f2 g_149 g_104 g_169 g_145 g_69 g_131 g_147 g_198 g_222 g_221 g_127
 * writes: g_21 g_102 g_104 g_90.f2 g_149 g_169 g_145 g_93.f1 g_147 g_198 g_222 g_127 g_69
 */
static int64_t  func_70(uint64_t  p_71)
{ /* block id: 22 */
    int32_t *l_72 = &g_21;
    union U0 *l_89 = &g_90;
    int32_t l_107 = 0L;
    int32_t l_115 = (-1L);
    uint64_t l_119 = 0x7FB9E8BD095E97E3LL;
    uint32_t l_181 = 0UL;
    const uint8_t *l_189 = &g_102;
    if (((*l_72) = (*g_13)))
    { /* block id: 24 */
        union U0 *l_92 = &g_93[6];
        union U0 **l_91 = &l_92;
        int32_t l_100 = 0xF4DE99E4L;
        uint8_t *l_101 = &g_102;
        int16_t *l_103 = &g_104[1][9];
        int32_t *l_108 = &g_21;
        int32_t *l_109 = &l_107;
        int32_t *l_110 = &l_107;
        int32_t *l_111 = &l_107;
        int32_t *l_112 = (void*)0;
        int32_t *l_113 = &l_107;
        int32_t *l_114 = &l_107;
        int32_t *l_116 = &l_100;
        int32_t *l_117 = &l_107;
        int32_t *l_118 = (void*)0;
        (*l_72) = (safe_sub_func_uint64_t_u_u(0UL, ((void*)0 != &g_21)));
        (*l_72) = (p_71 <= (safe_lshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u((((safe_div_func_int16_t_s_s((((safe_add_func_uint8_t_u_u((7UL != 0x630EL), p_71)) , (safe_div_func_uint32_t_u_u((p_71 ^ ((*l_103) = ((((*l_101) ^= ((safe_lshift_func_int8_t_s_u((((safe_div_func_uint8_t_u_u(((l_89 == ((*l_91) = l_89)) , ((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(g_66[7][1], (~5L))) , l_100), p_71)), (*l_72))) & p_71)), g_23)) ^ 0xAC47384F12CA17A5LL) , (*l_72)), 7)) ^ g_62[6][0])) > (*l_72)) > p_71))), g_62[2][1]))) ^ 65535UL), g_93[6].f1)) , l_100) | l_100), p_71)), 9)));
        l_107 = ((*l_72) |= (safe_div_func_uint8_t_u_u(g_90.f1, l_100)));
        l_119++;
    }
    else
    { /* block id: 33 */
        int32_t l_129[1][7][1];
        uint32_t l_135 = 1UL;
        volatile union U0 *l_139 = &g_140;
        int32_t *l_141 = &g_21;
        int32_t l_146 = 0x9C4FFD0FL;
        uint16_t l_157 = 0xAB78L;
        int8_t l_159 = 0x61L;
        uint64_t l_163 = 0x99DA232D690D09DFLL;
        uint32_t l_245[9][4] = {{1UL,18446744073709551607UL,18446744073709551607UL,1UL},{0UL,18446744073709551607UL,3UL,18446744073709551607UL},{18446744073709551607UL,3UL,3UL,3UL},{0UL,0UL,18446744073709551607UL,3UL},{1UL,3UL,1UL,18446744073709551607UL},{1UL,18446744073709551607UL,18446744073709551607UL,1UL},{0UL,18446744073709551607UL,3UL,18446744073709551607UL},{18446744073709551607UL,3UL,3UL,3UL},{0UL,0UL,18446744073709551607UL,3UL}};
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 7; j++)
            {
                for (k = 0; k < 1; k++)
                    l_129[i][j][k] = 0x59FC79B8L;
            }
        }
lbl_201:
        for (g_21 = 23; (g_21 <= (-7)); --g_21)
        { /* block id: 36 */
            int32_t *l_124 = &l_107;
            int32_t *l_125 = &l_107;
            int32_t *l_126 = &l_115;
            int32_t *l_128 = &l_115;
            int32_t *l_130 = &l_115;
            int32_t *l_132 = &g_131;
            int32_t *l_133 = &l_107;
            int32_t *l_134[7];
            int i;
            for (i = 0; i < 7; i++)
                l_134[i] = &l_107;
            ++l_135;
            l_139 = g_138;
            (*l_130) &= (0xAE722093L == ((*l_72) >= (-6L)));
        }
lbl_188:
        l_141 = &l_115;
        for (l_135 = 2; (l_135 <= 6); l_135 += 1)
        { /* block id: 44 */
            int64_t l_148 = 0x0F64802BCF3F1ECALL;
            int32_t l_158 = 0x085447BDL;
            for (g_90.f2 = 0; (g_90.f2 <= 6); g_90.f2 += 1)
            { /* block id: 47 */
                int32_t *l_142 = &g_21;
                int32_t *l_143 = (void*)0;
                int32_t *l_144[5][10] = {{(void*)0,(void*)0,(void*)0,&g_21,&g_131,(void*)0,&l_115,&l_107,&g_21,&g_21},{&l_107,(void*)0,&g_131,&g_131,&g_131,&g_131,(void*)0,&l_107,&g_131,&g_131},{&l_107,&l_115,(void*)0,&g_131,&g_21,(void*)0,(void*)0,(void*)0,&g_21,&g_131},{(void*)0,(void*)0,(void*)0,&g_21,&g_131,(void*)0,&l_115,&l_107,&g_21,&g_21},{&l_107,(void*)0,&g_131,&g_131,&g_131,&g_131,(void*)0,&l_107,&g_131,&g_131}};
                int16_t *l_154 = &g_104[0][6];
                int i, j;
                ++g_149;
                (*l_142) = ((0x0A3929C8L || (l_144[2][6] != (void*)0)) , (((((((g_62[l_135][(l_135 + 2)] , ((safe_lshift_func_int16_t_s_s((((*l_154) ^= p_71) | (((*l_72) , (&g_102 == (void*)0)) < ((~(safe_div_func_uint32_t_u_u(0x01CBC849L, p_71))) && l_157))), p_71)) && g_66[7][1])) , g_21) < g_90.f2) == g_62[3][7]) || (*l_141)) ^ g_90.f1) , 0x49C3678AL));
            }
            l_158 = ((*l_141) = (*g_13));
            for (l_157 = 0; (l_157 <= 6); l_157 += 1)
            { /* block id: 56 */
                int32_t *l_160 = &l_158;
                int32_t *l_161 = &g_131;
                int32_t *l_162[10] = {&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21,&g_21};
                int i, j;
                if (g_62[l_157][(l_157 + 2)])
                    break;
                (*l_72) |= 4L;
                l_163--;
            }
        }
        if ((*l_141))
        { /* block id: 62 */
            uint32_t * const l_184[9][10][2] = {{{&l_135,&g_23},{&g_69,(void*)0},{&g_69,(void*)0},{&g_69,&g_23},{&l_135,(void*)0},{(void*)0,&l_135},{&l_135,&g_69},{&g_23,&g_23},{&l_135,&g_69},{&l_135,(void*)0}},{{&g_69,&g_69},{&g_23,&g_23},{(void*)0,&l_135},{&g_69,&l_135},{(void*)0,&g_23},{(void*)0,(void*)0},{&g_69,&l_135},{&g_69,(void*)0},{(void*)0,&g_23},{(void*)0,&l_135}},{{&g_69,&l_135},{(void*)0,&g_23},{&g_23,&g_69},{&g_69,(void*)0},{&l_135,&g_69},{&l_135,&g_23},{&g_23,(void*)0},{&l_135,&g_23},{(void*)0,&g_23},{&g_69,&g_69}},{{(void*)0,&l_135},{&g_23,&l_135},{(void*)0,&g_69},{&g_69,&g_23},{(void*)0,&g_23},{&l_135,(void*)0},{&g_23,&g_23},{&l_135,&g_69},{&l_135,(void*)0},{&g_69,&g_69}},{{&g_23,&g_23},{(void*)0,&l_135},{&g_69,&l_135},{(void*)0,&g_23},{(void*)0,(void*)0},{&g_69,&l_135},{&g_69,(void*)0},{(void*)0,&g_23},{(void*)0,&l_135},{&g_69,&l_135}},{{(void*)0,&g_23},{&g_23,&g_69},{&g_69,(void*)0},{&l_135,&g_69},{&l_135,&g_23},{&g_23,(void*)0},{&l_135,&g_23},{(void*)0,&g_23},{&g_69,&g_69},{(void*)0,&l_135}},{{&g_23,&l_135},{(void*)0,&g_69},{&g_69,&g_23},{(void*)0,&g_23},{&l_135,(void*)0},{&g_23,&g_23},{&l_135,&g_69},{&l_135,(void*)0},{&g_69,&g_69},{&g_23,&g_23}},{{(void*)0,&l_135},{&g_69,&l_135},{(void*)0,&g_23},{(void*)0,(void*)0},{&g_69,&l_135},{&g_69,(void*)0},{(void*)0,&g_23},{(void*)0,&l_135},{&g_69,&l_135},{(void*)0,&g_23}},{{&g_23,&g_69},{&g_69,(void*)0},{&l_135,&g_69},{&l_135,&g_23},{&g_23,(void*)0},{&l_135,&g_23},{(void*)0,&g_23},{&g_69,&g_69},{(void*)0,&l_135},{&g_23,&l_135}}};
            int32_t l_195 = (-1L);
            int i, j, k;
            for (g_21 = 0; (g_21 <= 0); g_21 += 1)
            { /* block id: 65 */
                int16_t l_197 = 0xC2A3L;
                for (l_135 = 2; (l_135 <= 6); l_135 += 1)
                { /* block id: 68 */
                    int32_t *l_166 = &l_107;
                    int32_t *l_167 = &l_107;
                    int32_t *l_168[6][2];
                    int i, j;
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 2; j++)
                            l_168[i][j] = &l_146;
                    }
                    g_169++;
                    (*l_167) = ((safe_mul_func_uint16_t_u_u(((g_62[(g_21 + 3)][(g_21 + 2)] , 0xF463998EL) , 0x81CDL), ((((((((safe_mod_func_int64_t_s_s((safe_add_func_int32_t_s_s((safe_unary_minus_func_uint8_t_u(255UL)), (safe_mul_func_int8_t_s_s((p_71 != (l_181 == (((65535UL <= g_90.f1) ^ (safe_mod_func_int16_t_s_s(((void*)0 == l_184[3][8][0]), g_21))) , p_71))), g_104[1][9])))), (-1L))) || (*l_72)) , 0xE68E90F1L) > 0x449D27B8L) > g_145) != 0x0B985C477C23372FLL) , g_69) < 0x4CL))) >= (*l_72));
                    for (g_145 = 0; (g_145 <= 0); g_145 += 1)
                    { /* block id: 73 */
                        int16_t *l_187 = &g_104[1][9];
                        int16_t **l_186 = &l_187;
                        int16_t ***l_185 = &l_186;
                        (*l_185) = (void*)0;
                    }
                }
                if (l_115)
                    goto lbl_188;
                for (g_169 = 0; (g_169 <= 0); g_169 += 1)
                { /* block id: 80 */
                    uint8_t l_191 = 0xA8L;
                    if (((void*)0 == l_189))
                    { /* block id: 81 */
                        uint16_t *l_190[4];
                        int8_t *l_192 = &g_93[6].f1;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_190[i] = &l_157;
                        (*l_141) &= ((l_191 = (&g_21 == &g_21)) <= (0x9FL >= ((*l_192) = p_71)));
                    }
                    else
                    { /* block id: 85 */
                        return g_131;
                    }
                    for (g_147 = 0; (g_147 >= 0); g_147 -= 1)
                    { /* block id: 90 */
                        int32_t *l_193 = &l_115;
                        int32_t *l_194 = &l_107;
                        int32_t *l_196[5][3] = {{&l_115,&g_21,&l_115},{&l_115,&g_21,&l_115},{&l_115,&g_21,&l_115},{&l_115,&g_21,&l_115},{&l_115,&g_21,&l_115}};
                        int i, j, k;
                        g_198--;
                        (*l_193) ^= (g_138 == (void*)0);
                        if (l_129[g_21][g_21][g_169])
                            continue;
                        return g_149;
                    }
                    if (l_191)
                        break;
                }
            }
            return g_147;
        }
        else
        { /* block id: 100 */
            int16_t l_213 = (-4L);
            int16_t *l_233[5][3] = {{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&l_213,(void*)0,&l_213}};
            uint32_t *l_234 = &g_198;
            int i, j;
            if (g_23)
                goto lbl_201;
            for (g_145 = 6; (g_145 == 29); g_145 = safe_add_func_int64_t_s_s(g_145, 7))
            { /* block id: 104 */
                int32_t *l_204 = (void*)0;
                int32_t *l_205 = &l_115;
                int32_t *l_206 = &l_115;
                int32_t *l_207 = (void*)0;
                int32_t *l_208 = &l_115;
                int32_t *l_209 = &l_115;
                int32_t *l_210 = &g_131;
                int32_t *l_211 = &g_21;
                int32_t *l_212 = (void*)0;
                int32_t *l_214 = (void*)0;
                int32_t *l_215 = &g_131;
                int32_t *l_216 = &g_131;
                int32_t *l_217 = &g_131;
                int32_t *l_218 = &l_107;
                int32_t *l_219 = &g_21;
                int32_t *l_220[7] = {&l_107,&l_107,&l_107,&l_107,&l_107,&l_107,&l_107};
                int i;
                g_222++;
            }
            (*l_72) = (((safe_div_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((((g_102 , l_213) , (g_104[1][9] = (safe_sub_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(l_213, (*l_72))), p_71)))) ^ (~((void*)0 != l_234))) || (safe_mod_func_int64_t_s_s((((safe_unary_minus_func_int8_t_s(p_71)) , (safe_mul_func_int16_t_s_s(p_71, g_90.f2))) != g_93[6].f1), p_71))), g_221)), 0x580385B4L)) , g_62[0][4]) || (-1L));
            for (g_222 = 0; (g_222 != 12); g_222 = safe_add_func_int32_t_s_s(g_222, 8))
            { /* block id: 111 */
                int32_t **l_242 = &l_141;
                int32_t l_260 = (-5L);
                uint16_t *l_261 = (void*)0;
                uint16_t *l_262 = &g_169;
                (*l_141) = 0x09E70583L;
                (*l_242) = &l_107;
                if ((0L >= (((((g_104[0][5] || 0L) < ((((safe_div_func_uint16_t_u_u(p_71, (+p_71))) < ((**l_242) , l_245[6][0])) < ((((safe_mul_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u(((*l_262) = ((safe_div_func_int32_t_s_s((safe_mod_func_int16_t_s_s((l_260 = (safe_rshift_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(p_71, ((safe_mod_func_int32_t_s_s(0x0388DE0FL, (*l_141))) , p_71))), 11))), g_149)), (*l_72))) , g_21)), p_71)) , g_66[0][3]), 0xB7L)) , (-3L)) , g_102) , 0xA8L)) > p_71)) , p_71) >= l_213) == (**l_242))))
                { /* block id: 116 */
                    uint64_t l_267 = 0x6F8895823D9D43D6LL;
                    (**l_242) = (((g_23 > ((safe_rshift_func_int16_t_s_u((((safe_sub_func_uint8_t_u_u(l_267, ((**l_242) , (g_127 = (safe_add_func_uint16_t_u_u(0x2084L, 0x0F34L)))))) , (((safe_sub_func_uint64_t_u_u((p_71 ^ (0xE9E9086AL & ((safe_rshift_func_int8_t_s_u(g_221, 6)) > (safe_unary_minus_func_uint32_t_u((safe_lshift_func_uint16_t_u_u(0x0EC3L, 14))))))), g_127)) & g_93[6].f1) == (*g_13))) && 0L), g_90.f2)) , 7UL)) >= (*l_141)) , p_71);
                    (*l_72) = l_213;
                }
                else
                { /* block id: 120 */
                    for (g_69 = 0; (g_69 < 31); g_69 = safe_add_func_uint32_t_u_u(g_69, 5))
                    { /* block id: 123 */
                        if ((*l_141))
                            break;
                    }
                    for (g_145 = 6; (g_145 >= 0); g_145 -= 1)
                    { /* block id: 128 */
                        (*l_72) &= (*l_141);
                        return p_71;
                    }
                }
            }
        }
    }
    return p_71;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    transparent_crc(g_21, "g_21", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_28, "g_28", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_62[i][j], "g_62[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_66[i][j], "g_66[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_67, "g_67", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_90.f0, "g_90.f0", print_hash_value);
    transparent_crc(g_90.f1, "g_90.f1", print_hash_value);
    transparent_crc(g_90.f2, "g_90.f2", print_hash_value);
    transparent_crc(g_90.f3, "g_90.f3", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_93[i].f0, "g_93[i].f0", print_hash_value);
        transparent_crc(g_93[i].f1, "g_93[i].f1", print_hash_value);
        transparent_crc(g_93[i].f2, "g_93[i].f2", print_hash_value);
        transparent_crc(g_93[i].f3, "g_93[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_102, "g_102", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_104[i][j], "g_104[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_131, "g_131", print_hash_value);
    transparent_crc(g_140.f0, "g_140.f0", print_hash_value);
    transparent_crc(g_140.f1, "g_140.f1", print_hash_value);
    transparent_crc(g_140.f2, "g_140.f2", print_hash_value);
    transparent_crc(g_140.f3, "g_140.f3", print_hash_value);
    transparent_crc(g_145, "g_145", print_hash_value);
    transparent_crc(g_147, "g_147", print_hash_value);
    transparent_crc(g_149, "g_149", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_198, "g_198", print_hash_value);
    transparent_crc(g_221, "g_221", print_hash_value);
    transparent_crc(g_222, "g_222", print_hash_value);
    transparent_crc(g_289.f0, "g_289.f0", print_hash_value);
    transparent_crc(g_289.f1, "g_289.f1", print_hash_value);
    transparent_crc(g_289.f2, "g_289.f2", print_hash_value);
    transparent_crc(g_289.f3, "g_289.f3", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    transparent_crc(g_312, "g_312", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_315[i][j][k], "g_315[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_340.f0, "g_340.f0", print_hash_value);
    transparent_crc(g_340.f1, "g_340.f1", print_hash_value);
    transparent_crc(g_340.f2, "g_340.f2", print_hash_value);
    transparent_crc(g_340.f3, "g_340.f3", print_hash_value);
    transparent_crc(g_363, "g_363", print_hash_value);
    transparent_crc(g_366, "g_366", print_hash_value);
    transparent_crc(g_400, "g_400", print_hash_value);
    transparent_crc(g_402, "g_402", print_hash_value);
    transparent_crc(g_423, "g_423", print_hash_value);
    transparent_crc(g_459, "g_459", print_hash_value);
    transparent_crc(g_470, "g_470", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_546[i][j], "g_546[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_599, "g_599", print_hash_value);
    transparent_crc(g_615, "g_615", print_hash_value);
    transparent_crc(g_625, "g_625", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_697[i][j], "g_697[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_731.f0, "g_731.f0", print_hash_value);
    transparent_crc(g_731.f1, "g_731.f1", print_hash_value);
    transparent_crc(g_731.f2, "g_731.f2", print_hash_value);
    transparent_crc(g_731.f3, "g_731.f3", print_hash_value);
    transparent_crc(g_1033, "g_1033", print_hash_value);
    transparent_crc(g_1048, "g_1048", print_hash_value);
    transparent_crc(g_1063, "g_1063", print_hash_value);
    transparent_crc(g_1098, "g_1098", print_hash_value);
    transparent_crc(g_1164, "g_1164", print_hash_value);
    transparent_crc(g_1322.f0, "g_1322.f0", print_hash_value);
    transparent_crc(g_1322.f1, "g_1322.f1", print_hash_value);
    transparent_crc(g_1322.f2, "g_1322.f2", print_hash_value);
    transparent_crc(g_1322.f3, "g_1322.f3", print_hash_value);
    transparent_crc(g_1355, "g_1355", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1371[i], "g_1371[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1374, "g_1374", print_hash_value);
    transparent_crc(g_1381, "g_1381", print_hash_value);
    transparent_crc(g_1386.f0, "g_1386.f0", print_hash_value);
    transparent_crc(g_1386.f1, "g_1386.f1", print_hash_value);
    transparent_crc(g_1386.f2, "g_1386.f2", print_hash_value);
    transparent_crc(g_1386.f3, "g_1386.f3", print_hash_value);
    transparent_crc(g_1414, "g_1414", print_hash_value);
    transparent_crc(g_1500, "g_1500", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1539[i], "g_1539[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1587, "g_1587", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1592[i][j][k].f0, "g_1592[i][j][k].f0", print_hash_value);
                transparent_crc(g_1592[i][j][k].f1, "g_1592[i][j][k].f1", print_hash_value);
                transparent_crc(g_1592[i][j][k].f2, "g_1592[i][j][k].f2", print_hash_value);
                transparent_crc(g_1592[i][j][k].f3, "g_1592[i][j][k].f3", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1601.f0, "g_1601.f0", print_hash_value);
    transparent_crc(g_1601.f1, "g_1601.f1", print_hash_value);
    transparent_crc(g_1601.f2, "g_1601.f2", print_hash_value);
    transparent_crc(g_1601.f3, "g_1601.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1634[i], "g_1634[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1635, "g_1635", print_hash_value);
    transparent_crc(g_1638, "g_1638", print_hash_value);
    transparent_crc(g_1639, "g_1639", print_hash_value);
    transparent_crc(g_1645, "g_1645", print_hash_value);
    transparent_crc(g_1893, "g_1893", print_hash_value);
    transparent_crc(g_1923, "g_1923", print_hash_value);
    transparent_crc(g_1926, "g_1926", print_hash_value);
    transparent_crc(g_1982.f0, "g_1982.f0", print_hash_value);
    transparent_crc(g_1982.f1, "g_1982.f1", print_hash_value);
    transparent_crc(g_1982.f2, "g_1982.f2", print_hash_value);
    transparent_crc(g_1982.f3, "g_1982.f3", print_hash_value);
    transparent_crc(g_2100, "g_2100", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2113[i].f0, "g_2113[i].f0", print_hash_value);
        transparent_crc(g_2113[i].f1, "g_2113[i].f1", print_hash_value);
        transparent_crc(g_2113[i].f2, "g_2113[i].f2", print_hash_value);
        transparent_crc(g_2113[i].f3, "g_2113[i].f3", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_2221[i], "g_2221[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2253, "g_2253", print_hash_value);
    transparent_crc(g_2331.f0, "g_2331.f0", print_hash_value);
    transparent_crc(g_2331.f1, "g_2331.f1", print_hash_value);
    transparent_crc(g_2331.f2, "g_2331.f2", print_hash_value);
    transparent_crc(g_2331.f3, "g_2331.f3", print_hash_value);
    transparent_crc(g_2428, "g_2428", print_hash_value);
    transparent_crc(g_2467, "g_2467", print_hash_value);
    transparent_crc(g_2488, "g_2488", print_hash_value);
    transparent_crc(g_2515.f0, "g_2515.f0", print_hash_value);
    transparent_crc(g_2515.f1, "g_2515.f1", print_hash_value);
    transparent_crc(g_2515.f2, "g_2515.f2", print_hash_value);
    transparent_crc(g_2515.f3, "g_2515.f3", print_hash_value);
    transparent_crc(g_2600, "g_2600", print_hash_value);
    transparent_crc(g_2616, "g_2616", print_hash_value);
    transparent_crc(g_2650, "g_2650", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 623
XXX total union variables: 2

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 54
breakdown:
   depth: 1, occurrence: 292
   depth: 2, occurrence: 97
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 13, occurrence: 2
   depth: 14, occurrence: 1
   depth: 16, occurrence: 3
   depth: 17, occurrence: 5
   depth: 18, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 3
   depth: 21, occurrence: 4
   depth: 22, occurrence: 2
   depth: 23, occurrence: 6
   depth: 24, occurrence: 3
   depth: 25, occurrence: 5
   depth: 26, occurrence: 3
   depth: 27, occurrence: 3
   depth: 28, occurrence: 2
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 1
   depth: 42, occurrence: 2
   depth: 45, occurrence: 1
   depth: 54, occurrence: 1

XXX total number of pointers: 552

XXX times a variable address is taken: 1481
XXX times a pointer is dereferenced on RHS: 476
breakdown:
   depth: 1, occurrence: 329
   depth: 2, occurrence: 97
   depth: 3, occurrence: 33
   depth: 4, occurrence: 16
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 415
breakdown:
   depth: 1, occurrence: 355
   depth: 2, occurrence: 40
   depth: 3, occurrence: 13
   depth: 4, occurrence: 6
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 70
XXX times a pointer is compared with address of another variable: 19
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 5774

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1604
   level: 2, occurrence: 489
   level: 3, occurrence: 283
   level: 4, occurrence: 129
   level: 5, occurrence: 28
XXX number of pointers point to pointers: 228
XXX number of pointers point to scalars: 307
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.3
XXX average alias set size: 1.5

XXX times a non-volatile is read: 2522
XXX times a non-volatile is write: 1297
XXX times a volatile is read: 35
XXX    times read thru a pointer: 20
XXX times a volatile is write: 4
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 490
XXX percentage of non-volatile access: 99

XXX forward jumps: 0
XXX backward jumps: 10

XXX stmts: 308
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 48
   depth: 2, occurrence: 58
   depth: 3, occurrence: 57
   depth: 4, occurrence: 49
   depth: 5, occurrence: 64

XXX percentage a fresh-made variable is used: 18.6
XXX percentage an existing variable is used: 81.4
********************* end of statistics **********************/

